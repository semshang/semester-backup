﻿<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="/styles.css"/>
		<title>Jo's Jobs - IT Jobs</title>
	</head>
	<body>
	<header>
		<section>
			<aside>
				<h3>Office Hours:</h3>
				<p>Mon-Fri: 09:00-17:30</p>
				<p>Sat: 09:00-17:00</p>
				<p>Sun: Closed</p>
			</aside>
			<h1>Jo's Jobs</h1>

		</section>
	</header>
	<nav>
		<ul>
			<li><a href="/">Home</a></li>
<?php include __DIR__ . '/inc/category-nav.php'; renderCategoryNav(1); ?>
			<li><a href="/categories.php">Categories</a></li>
			<li><a href="/careers-advice.php">Careers Advice</a></li>
			<li><a href="/about.php">About Us</a></li>
		</ul>

	</nav>
	<img src="images/randombanner.php"/>
	<main class="sidebar">

	<section class="left">
		<ul>
			<li  class="current" ><a href="it.php">IT</a></li>
			<li><a href="hr.php">Human Resources</a></li>
			<li><a href="sales.php">Sales</a></li>
		</ul>
	</section>

	<section class="right">

		<h1>IT Jobs</h1>

	<ul class="listing">


	<?php
	$pdo = new PDO('mysql:dbname=jobs;host=mysql', 'student', 'student');
	$stmt = $pdo->prepare('SELECT * FROM job WHERE categoryId = 1 AND closingDate > :date AND (archived IS NULL OR archived = 0)');

	$date = new DateTime();

	$values = [
		'date' => $date->format('Y-m-d')
	];

	$stmt->execute($values);


	foreach ($stmt as $job) {
		echo '<li>';

		echo '<div class="details">';
		echo '<h2>' . $job['title'] . '</h2>';
		echo '<h3>' . $job['salary'] . '</h3>';
		echo '<p>' . nl2br($job['description']) . '</p>';

		echo '<a class="more" href="/apply.php?id=' . $job['id'] . '">Apply for this job</a>';

		echo '</div>';
		echo '</li>';
	}

	?>

</ul>

</section>
	</main>


	<footer>
		&copy; Jo's Jobs <?= date('Y') ?>
</body>
</html>


