use bookdb;

-- Book 1
INSERT INTO book (book_isbn, book_title, category, no_of_books) VALUES ('978-0134685991', 'Effective Java', 'Programming', 10);
INSERT INTO author (author_name, author_mail_id, book_isbn) VALUES ('Joshua Bloch', 'joshua@example.com', '978-0134685991');

-- Book 2
INSERT INTO book (book_isbn, book_title, category, no_of_books) VALUES ('978-0201633610', 'Design Patterns', 'Programming', 5);
INSERT INTO author (author_name, author_mail_id, book_isbn) VALUES ('Erich Gamma', 'erich@example.com', '978-0201633610');

-- Book 3
INSERT INTO book (book_isbn, book_title, category, no_of_books) VALUES ('978-0132350884', 'Clean Code', 'Programming', 12);
INSERT INTO author (author_name, author_mail_id, book_isbn) VALUES ('Robert C. Martin', 'robert@example.com', '978-0132350884');

-- Book 4
INSERT INTO book (book_isbn, book_title, category, no_of_books) VALUES ('978-1491950357', 'Building Microservices', 'Architecture', 7);
INSERT INTO author (author_name, author_mail_id, book_isbn) VALUES ('Sam Newman', 'sam@example.com', '978-1491950357');

-- Book 5
INSERT INTO book (book_isbn, book_title, category, no_of_books) VALUES ('978-0321356680', 'Effective C++', 'Programming', 4);
INSERT INTO author (author_name, author_mail_id, book_isbn) VALUES ('Scott Meyers', 'scott@example.com', '978-0321356680');
