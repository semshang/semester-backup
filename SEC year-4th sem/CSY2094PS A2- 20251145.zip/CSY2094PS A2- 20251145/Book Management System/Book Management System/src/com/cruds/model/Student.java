package com.cruds.model;

/**
 * Represents a student in the Library Management System.
 */
public class Student extends UserAccount {
	
	/**
	 * Constructs a new Student.
	 * @param usn the unique student number (acts as ID)
	 * @param name the student's name
	 */
	public Student(String usn, String name) {
		super(usn, name);
	}

	/**
	 * Gets the student's USN.
	 * @return the USN
	 */
	public String getUsn() {
		return getId();
	}

	/**
	 * Sets the student's USN.
	 * @param usn the USN to set
	 */
	public void setUsn(String usn) {
		setId(usn);
	}

	@Override
	public String toString() {
		return "Student [usn=" + getUsn() + ", name=" + getName() + "]";
	}
}
