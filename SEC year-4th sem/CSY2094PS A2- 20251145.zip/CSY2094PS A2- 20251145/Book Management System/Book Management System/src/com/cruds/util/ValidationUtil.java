package com.cruds.util;

import com.cruds.exception.ValidationException;
import java.util.regex.Pattern;

/**
 * Utility class for validating user input across the Library Management System.
 * Ensures input integrity for ISBN, student USN, names, emails, and stock counts,
 * throwing ValidationException with descriptive messages when validation fails.
 */
public class ValidationUtil {

    private static final Pattern ISBN_PATTERN = Pattern.compile("^[0-9A-Za-z\\-\\s]{3,25}$");
    private static final Pattern USN_PATTERN = Pattern.compile("^[0-9A-Za-z\\-_]{2,20}$");
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    /**
     * Validates that a string is neither null nor empty.
     *
     * @param input the string to validate
     * @param fieldName the name of the field for the error message
     * @throws ValidationException if the string is null or empty
     */
    public static void validateNotEmpty(String input, String fieldName) {
        if (input == null || input.trim().isEmpty()) {
            throw new ValidationException(fieldName + " cannot be empty.");
        }
    }

    /**
     * Validates that an integer is greater than or equal to a minimum value.
     *
     * @param value the value to validate
     * @param minValue the minimum allowed value
     * @param fieldName the name of the field for the error message
     * @throws ValidationException if the value is less than minValue
     */
    public static void validateMinimum(int value, int minValue, String fieldName) {
        if (value < minValue) {
            throw new ValidationException(fieldName + " must be at least " + minValue + ".");
        }
    }

    /**
     * Validates an ISBN string format and ensures it is not empty.
     *
     * @param isbn the ISBN to validate
     * @throws ValidationException if ISBN is null, empty, or has an invalid format
     */
    public static void validateIsbn(String isbn) {
        validateNotEmpty(isbn, "Book ISBN");
        String trimmed = isbn.trim();
        if (!ISBN_PATTERN.matcher(trimmed).matches()) {
            throw new ValidationException("Invalid ISBN format. Must be 3-25 alphanumeric characters (hyphens allowed).");
        }
    }

    /**
     * Validates that the book stock / quantity is non-negative (>= 0).
     *
     * @param stock the quantity value
     * @throws ValidationException if stock is less than 0
     */
    public static void validateStock(int stock) {
        if (stock < 0) {
            throw new ValidationException("Book quantity/stock must be 0 or greater.");
        }
    }

    /**
     * Parses and validates a stock string.
     *
     * @param stockStr the quantity string from UI
     * @return parsed integer quantity
     * @throws ValidationException if empty, not an integer, or negative
     */
    public static int parseAndValidateStock(String stockStr) {
        validateNotEmpty(stockStr, "Quantity");
        try {
            int val = Integer.parseInt(stockStr.trim());
            validateStock(val);
            return val;
        } catch (NumberFormatException e) {
            throw new ValidationException("Quantity must be a valid integer number.");
        }
    }

    /**
     * Validates University Seat Number (USN) format.
     *
     * @param usn the student USN
     * @throws ValidationException if USN is null, empty, or improperly formatted
     */
    public static void validateUsn(String usn) {
        validateNotEmpty(usn, "Student USN");
        String trimmed = usn.trim();
        if (!USN_PATTERN.matcher(trimmed).matches()) {
            throw new ValidationException("Invalid USN format. Must be 2-20 alphanumeric characters.");
        }
    }

    /**
     * Validates a person's name.
     *
     * @param name the name to validate
     * @param fieldName field label for error message
     * @throws ValidationException if name is empty or too short
     */
    public static void validateName(String name, String fieldName) {
        validateNotEmpty(name, fieldName);
        if (name.trim().length() < 2) {
            throw new ValidationException(fieldName + " must be at least 2 characters long.");
        }
    }

    /**
     * Validates email address format.
     *
     * @param email the email to validate
     * @throws ValidationException if email is invalid
     */
    public static void validateEmail(String email) {
        validateNotEmpty(email, "Author Email");
        if (!EMAIL_PATTERN.matcher(email.trim()).matches()) {
            throw new ValidationException("Invalid email format (e.g. author@domain.com).");
        }
    }
}
