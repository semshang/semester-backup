package com.cruds.exception;

/**
 * Base custom exception for Library Management System errors.
 */
public class LibraryException extends RuntimeException {

    /**
     * Constructs a new LibraryException with the specified message.
     * @param message the detail message
     */
    public LibraryException(String message) {
        super(message);
    }

    /**
     * Constructs a new LibraryException with the specified message and cause.
     * @param message the detail message
     * @param cause the cause
     */
    public LibraryException(String message, Throwable cause) {
        super(message, cause);
    }
}
