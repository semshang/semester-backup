package com.cruds.model;

/**
 * Abstract base class representing a generic user account in the system.
 */
public abstract class UserAccount implements Persistable {
    private String id;
    private String name;

    /**
     * Constructs a new UserAccount.
     * @param id the unique identifier for the user
     * @param name the full name of the user
     */
    public UserAccount(String id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets the full name of the user.
     * @return the name
     */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
