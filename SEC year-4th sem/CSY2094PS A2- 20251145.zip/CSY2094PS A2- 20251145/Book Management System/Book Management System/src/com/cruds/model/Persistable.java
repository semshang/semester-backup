package com.cruds.model;

/**
 * Common interface for entities that can be saved to the database.
 */
public interface Persistable {
    /**
     * Gets the unique identifier for this entity.
     * @return the ID
     */
    String getId();
}
