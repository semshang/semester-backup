package com.cruds.db;

import com.cruds.exception.LibraryException;
import com.cruds.exception.ValidationException;
import com.cruds.model.Author;
import com.cruds.model.Book;
import com.cruds.model.Issue;
import com.cruds.model.LibraryItem;
import com.cruds.model.Magazine;
import com.cruds.model.Student;
import com.cruds.util.DBConnectionManager;
import com.cruds.util.ValidationUtil;

import java.sql.Connection;
import java.util.Calendar;
import java.util.Date;
import javax.swing.table.DefaultTableModel;

/**
 * Automated verification test suite for CSY2094 Library Management System.
 * Tests DB connection, CRUD operations, transactions, overdue reports, and OOP polymorphism.
 */
public class TestAllFeatures {

    public static void main(String[] args) {
        int passed = 0;
        int failed = 0;

        System.out.println("==================================================");
        System.out.println("  STARTING AUTOMATED VERIFICATION SUITE");
        System.out.println("==================================================");

        // 1. Test Database Connection
        try {
            System.out.print("[TEST 1] DBConnectionManager: ");
            Connection conn = DBConnectionManager.getConnection();
            if (conn != null && !conn.isClosed()) {
                System.out.println("PASSED (Connected via " + DBConnectionManager.getUser() + "@" + DBConnectionManager.getUrl() + ")");
                conn.close();
                passed++;
            } else {
                System.out.println("FAILED");
                failed++;
            }
        } catch (Exception e) {
            System.out.println("FAILED: " + e.getMessage());
            failed++;
        }

        // 2. Test ValidationUtil
        try {
            System.out.print("[TEST 2] ValidationUtil (bad ISBN, negative stock, bad USN): ");
            boolean caughtIsbn = false;
            try {
                ValidationUtil.validateIsbn("???!!!");
            } catch (ValidationException ve) {
                caughtIsbn = true;
            }

            boolean caughtStock = false;
            try {
                ValidationUtil.parseAndValidateStock("-5");
            } catch (ValidationException ve) {
                caughtStock = true;
            }

            boolean caughtUsn = false;
            try {
                ValidationUtil.validateUsn("");
            } catch (ValidationException ve) {
                caughtUsn = true;
            }

            if (caughtIsbn && caughtStock && caughtUsn) {
                System.out.println("PASSED (All invalid inputs caught with ValidationException)");
                passed++;
            } else {
                System.out.println("FAILED (One or more validations did not trigger)");
                failed++;
            }
        } catch (Exception e) {
            System.out.println("FAILED: " + e.getMessage());
            failed++;
        }

        // 3. Test OOP Abstraction & Polymorphism (LibraryItem, Book, Magazine)
        try {
            System.out.print("[TEST 3] OOP Abstraction & Polymorphism: ");
            LibraryItem item1 = new Book("TEST-ISBN-01", "Clean Architecture", "Software Engineering", 5);
            LibraryItem item2 = new Magazine("TEST-ISSN-01", "IEEE Software", 42, "IEEE Computer Society");

            int bookDays = item1.getLoanPeriodDays();
            double bookFine = item1.calculateFine(3); // 3 days * 0.50 = 1.50

            int magDays = item2.getLoanPeriodDays();
            double magFine = item2.calculateFine(3); // 3 days * 1.00 = 3.00

            if (bookDays == 14 && Math.abs(bookFine - 1.50) < 0.001 &&
                magDays == 7 && Math.abs(magFine - 3.00) < 0.001 &&
                item1.getItemType().equals("Book") && item2.getItemType().equals("Magazine")) {
                System.out.println("PASSED (Polymorphism verified: Book loan=" + bookDays + "d, fine=\u00A3" + bookFine +
                        " | Magazine loan=" + magDays + "d, fine=\u00A3" + magFine + ")");
                passed++;
            } else {
                System.out.println("FAILED (Values do not match expected polymorphic outputs)");
                failed++;
            }
        } catch (Exception e) {
            System.out.println("FAILED: " + e.getMessage());
            failed++;
        }

        // 4. Test Book CRUD & Student CRUD in BookDAO
        BookDAO dao = new BookDAO();
        String testIsbn = "978-0000000001";
        String testUsn = "STU-9999";
        try {
            System.out.print("[TEST 4] Student & Book CRUD (Create & Read): ");
            // Clean up any leftovers from previous test runs
            try { dao.deleteBook(testIsbn); } catch (Exception ignored) {}
            try { dao.deleteStudent(testUsn); } catch (Exception ignored) {}

            // Create
            Student s = new Student(testUsn, "Test Alice");
            dao.addStudent(s);
            Book b = new Book(testIsbn, "Test Driven Development", "Testing", 3);
            Author a = new Author("Kent Beck", "kent@example.com", testIsbn);
            dao.addBook(b);
            dao.addAuthor(a);

            // Read
            Student fetchedStudent = dao.getStudent(testUsn);
            Book fetchedBook = dao.getBook(testIsbn);

            if (fetchedStudent != null && "Test Alice".equals(fetchedStudent.getName()) &&
                fetchedBook != null && "Test Driven Development".equals(fetchedBook.getTitle())) {
                System.out.println("PASSED (Created and retrieved Student and Book)");
                passed++;
            } else {
                System.out.println("FAILED (Could not retrieve created records)");
                failed++;
            }
        } catch (Exception e) {
            System.out.println("FAILED: " + e.getMessage());
            failed++;
        }

        // 5. Test Update Operations
        try {
            System.out.print("[TEST 5] Update Book & Student: ");
            Student updatedStudent = new Student(testUsn, "Alice Bob Updated");
            boolean studUp = dao.updateStudent(updatedStudent);

            Book updatedBook = new Book(testIsbn, "Test Driven Development 2nd Ed", "Methodology", 4);
            Author updatedAuthor = new Author("Kent Beck Sr", "kent.beck@newemail.com", testIsbn);
            boolean bookUp = dao.updateBook(updatedBook, updatedAuthor);

            Student refetchedStudent = dao.getStudent(testUsn);
            Book refetchedBook = dao.getBook(testIsbn);
            Author refetchedAuthor = dao.getAuthor(testIsbn);

            if (studUp && bookUp && refetchedStudent != null && "Alice Bob Updated".equals(refetchedStudent.getName()) &&
                refetchedBook != null && "Test Driven Development 2nd Ed".equals(refetchedBook.getTitle()) &&
                refetchedBook.getQuantity() == 4 &&
                refetchedAuthor != null && "Kent Beck Sr".equals(refetchedAuthor.getName())) {
                System.out.println("PASSED (Book and Student successfully updated)");
                passed++;
            } else {
                System.out.println("FAILED (Update verification failed)");
                failed++;
            }
        } catch (Exception e) {
            System.out.println("FAILED: " + e.getMessage());
            failed++;
        }

        // 6. Test Transactions: issueBook & returnBook
        try {
            System.out.print("[TEST 6] Transactional Issue & Return: ");
            Calendar cal = Calendar.getInstance();
            Date issueDate = cal.getTime();
            cal.add(Calendar.DATE, 14);
            Date returnDate = cal.getTime();

            Issue issue = new Issue(testUsn, issueDate, returnDate, testIsbn);
            boolean issued = dao.issueBook(issue);

            Book bookAfterIssue = dao.getBook(testIsbn);
            // Stock was 4, should now be 3
            boolean stockDecremented = (bookAfterIssue != null && bookAfterIssue.getQuantity() == 3);

            // Find issue id
            DefaultTableModel issuedModel = dao.listBookByUsn(testUsn);
            int issueId = -1;
            if (issuedModel.getRowCount() > 0) {
                issueId = Integer.parseInt((String) issuedModel.getValueAt(0, 0));
            }

            boolean returned = false;
            if (issueId != -1) {
                returned = dao.returnBook(issueId, testIsbn);
            }

            Book bookAfterReturn = dao.getBook(testIsbn);
            // Stock should be back to 4
            boolean stockIncremented = (bookAfterReturn != null && bookAfterReturn.getQuantity() == 4);

            if (issued && stockDecremented && returned && stockIncremented) {
                System.out.println("PASSED (Issue decremented stock to 3, Return restored stock to 4 within transactions)");
                passed++;
            } else {
                System.out.println("FAILED (issued=" + issued + ", stockDecremented=" + stockDecremented +
                        ", returned=" + returned + ", stockIncremented=" + stockIncremented + ")");
                failed++;
            }
        } catch (Exception e) {
            System.out.println("FAILED: " + e.getMessage());
            failed++;
        }

        // 7. Test Overdue Report Calculation
        try {
            System.out.print("[TEST 7] Overdue Books & Fine Report: ");
            // Issue a book with a past return date (e.g. 5 days ago)
            Calendar pastCal = Calendar.getInstance();
            pastCal.add(Calendar.DATE, -10);
            Date pastIssueDate = pastCal.getTime();
            pastCal.add(Calendar.DATE, 5); // due 5 days ago
            Date pastReturnDate = pastCal.getTime();

            Issue overdueIssue = new Issue(testUsn, pastIssueDate, pastReturnDate, testIsbn);
            dao.issueBook(overdueIssue);

            DefaultTableModel overdueModel = dao.getOverdueBooks(new Date(), Book.DAILY_FINE_RATE);
            boolean foundOverdue = false;
            double fineRecorded = 0.0;
            int overdueIssueId = -1;

            for (int r = 0; r < overdueModel.getRowCount(); r++) {
                String usn = (String) overdueModel.getValueAt(r, 2);
                if (testUsn.equals(usn)) {
                    foundOverdue = true;
                    overdueIssueId = Integer.parseInt((String) overdueModel.getValueAt(r, 0));
                    fineRecorded = Double.parseDouble((String) overdueModel.getValueAt(r, 7));
                    break;
                }
            }

            // Clean up: return the overdue book
            if (overdueIssueId != -1) {
                dao.returnBook(overdueIssueId, testIsbn);
            }

            if (foundOverdue && fineRecorded > 0.0) {
                System.out.println("PASSED (Detected overdue book with fine \u00A3" + String.format("%.2f", fineRecorded) + ")");
                passed++;
            } else {
                System.out.println("FAILED (Overdue book not detected or fine was 0)");
                failed++;
            }
        } catch (Exception e) {
            System.out.println("FAILED: " + e.getMessage());
            failed++;
        }

        // 8. Test Delete Operations
        try {
            System.out.print("[TEST 8] Delete Operations & Foreign Key Protection: ");
            // Clean deletion of student and book
            boolean delBook = dao.deleteBook(testIsbn);
            boolean delStud = dao.deleteStudent(testUsn);

            if (delBook && delStud && dao.getBook(testIsbn) == null && dao.getStudent(testUsn) == null) {
                System.out.println("PASSED (Successfully cleaned up test book and test student)");
                passed++;
            } else {
                System.out.println("FAILED (Records still present after delete)");
                failed++;
            }
        } catch (Exception e) {
            System.out.println("FAILED: " + e.getMessage());
            failed++;
        }

        System.out.println("==================================================");
        System.out.println("  SUMMARY: " + passed + " PASSED, " + failed + " FAILED");
        System.out.println("==================================================");
    }
}
