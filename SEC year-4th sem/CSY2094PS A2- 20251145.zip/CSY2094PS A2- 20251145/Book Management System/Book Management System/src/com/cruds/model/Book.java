package com.cruds.model;

/**
 * Represents a book in the Library Management System.
 * Inherits common attributes and identity from LibraryItem and provides
 * concrete implementations of loan period and fine calculation demonstrating Polymorphism.
 */
public class Book extends LibraryItem {

	private String category;
	private int quantity;

	/** Standard loan period for books is 14 days. */
	public static final int STANDARD_LOAN_DAYS = 14;

	/** Standard late fee for books is £0.50 per day. */
	public static final double DAILY_FINE_RATE = 0.50;

	/**
	 * Constructs a new Book.
	 *
	 * @param isbn the book's ISBN (acts as unique ID)
	 * @param title the title of the book
	 * @param category the category of the book
	 * @param quantity the quantity of the book available
	 */
	public Book(String isbn, String title, String category, int quantity) {
		super(isbn, title);
		this.category = category;
		this.quantity = quantity;
	}

	/**
	 * Gets the ISBN.
	 *
	 * @return the ISBN
	 */
	public String getIsbn() {
		return getId();
	}

	/**
	 * Sets the ISBN.
	 *
	 * @param isbn the ISBN to set
	 */
	public void setIsbn(String isbn) {
		setId(isbn);
	}

	/**
	 * Gets the category.
	 *
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * Sets the category.
	 *
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * Gets the quantity.
	 *
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * Sets the quantity.
	 *
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/**
	 * Demonstrates Polymorphism: Books have a standard 14-day loan duration.
	 *
	 * @return 14 days
	 */
	@Override
	public int getLoanPeriodDays() {
		return STANDARD_LOAN_DAYS;
	}

	/**
	 * Demonstrates Polymorphism: Overdue books incur £0.50 per day overdue.
	 *
	 * @param daysOverdue the number of days past due
	 * @return calculated fine amount in £
	 */
	@Override
	public double calculateFine(int daysOverdue) {
		if (daysOverdue <= 0) {
			return 0.0;
		}
		return daysOverdue * DAILY_FINE_RATE;
	}

	/**
	 * Returns "Book" as the item type.
	 *
	 * @return "Book"
	 */
	@Override
	public String getItemType() {
		return "Book";
	}

	@Override
	public String toString() {
		return "" + getIsbn() + "\t\t" + getTitle() + "\t\t" + category + "\t\t" + quantity;
	}
}
