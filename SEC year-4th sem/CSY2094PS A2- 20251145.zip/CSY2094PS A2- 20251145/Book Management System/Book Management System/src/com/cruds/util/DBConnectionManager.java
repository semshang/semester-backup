package com.cruds.util;

import com.cruds.exception.LibraryException;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Utility class for managing database connections.
 * Reads database connection configuration from config.properties with
 * sensible defaults (root user with empty password on localhost:3306/bookdb).
 */
public class DBConnectionManager {

	private static final String DEFAULT_DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String DEFAULT_URL = "jdbc:mysql://localhost:3306/bookdb?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
	private static final String DEFAULT_USER = "root";
	private static final String DEFAULT_PASSWORD = "";

	private static String driverClass;
	private static String url;
	private static String user;
	private static String password;

	static {
		loadConfiguration();
	}

	/**
	 * Loads configuration from config.properties or falls back to defaults.
	 */
	private static void loadConfiguration() {
		Properties props = new Properties();
		boolean loaded = false;

		// 1. Try classpath resource
		try (InputStream in = DBConnectionManager.class.getClassLoader().getResourceAsStream("config.properties")) {
			if (in != null) {
				props.load(in);
				loaded = true;
			}
		} catch (Exception ignored) {
		}

		// 2. Try file system locations if not found in classpath
		if (!loaded) {
			String[] searchPaths = {
				"config.properties",
				"Library-Management-master/config.properties",
				"Library-Management-master/Library-Management-master/config.properties",
				"Library-Management-master/Library-Management-master/src/config.properties"
			};
			for (String path : searchPaths) {
				File f = new File(path);
				if (f.exists() && f.isFile()) {
					try (FileInputStream fis = new FileInputStream(f)) {
						props.load(fis);
						loaded = true;
						break;
					} catch (Exception ignored) {
					}
				}
			}
		}

		driverClass = props.getProperty("db.driver", DEFAULT_DRIVER).trim();
		url = props.getProperty("db.url", DEFAULT_URL).trim();
		user = props.getProperty("db.user", DEFAULT_USER).trim();
		password = props.getProperty("db.password", DEFAULT_PASSWORD);
		if (password != null) {
			password = password.trim();
		} else {
			password = "";
		}

		try {
			Class.forName(driverClass);
		} catch (ClassNotFoundException e) {
			// Fallback to legacy driver if newer driver not found on classpath
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException ex) {
				throw new LibraryException("MySQL Driver (" + driverClass + ") not found.", e);
			}
		}
	}

	/**
	 * Gets a connection to the database.
	 * @return a Connection object
	 * @throws LibraryException if a database access error occurs
	 */
	public static Connection getConnection() {
		try {
			return DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			throw new LibraryException("Failed to connect to the database. URL: " + url + ", User: " + user, e);
		}
	}

	/**
	 * Gets configured database URL.
	 * @return database URL
	 */
	public static String getUrl() {
		return url;
	}

	/**
	 * Gets configured database user.
	 * @return database user
	 */
	public static String getUser() {
		return user;
	}
}
