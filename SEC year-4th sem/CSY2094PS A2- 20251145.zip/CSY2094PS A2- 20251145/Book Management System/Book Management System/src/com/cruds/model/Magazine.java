package com.cruds.model;

/**
 * Represents a periodical or magazine in the Library Management System.
 * Demonstrates Inheritance by extending LibraryItem and Polymorphism by
 * overriding loan period (7 days) and fine calculation (£1.00/day).
 */
public class Magazine extends LibraryItem {

    private int issueNumber;
    private String publisher;

    /** Standard loan period for magazines/periodicals is 7 days. */
    public static final int STANDARD_LOAN_DAYS = 7;

    /** Higher fine rate for high-demand periodicals: £1.00 per day. */
    public static final double DAILY_FINE_RATE = 1.00;

    /**
     * Constructs a new Magazine item.
     *
     * @param issn the magazine's ISSN / ID
     * @param title the magazine title
     * @param issueNumber the issue or volume number
     * @param publisher the publishing house or organization
     */
    public Magazine(String issn, String title, int issueNumber, String publisher) {
        super(issn, title);
        this.issueNumber = issueNumber;
        this.publisher = publisher;
    }

    /**
     * Gets the issue number.
     *
     * @return the issue number
     */
    public int getIssueNumber() {
        return issueNumber;
    }

    /**
     * Sets the issue number.
     *
     * @param issueNumber the issue number to set
     */
    public void setIssueNumber(int issueNumber) {
        this.issueNumber = issueNumber;
    }

    /**
     * Gets the publisher.
     *
     * @return the publisher name
     */
    public String getPublisher() {
        return publisher;
    }

    /**
     * Sets the publisher.
     *
     * @param publisher publisher name to set
     */
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    /**
     * Demonstrates Polymorphism: Magazines have a shorter loan duration (7 days).
     *
     * @return 7 days
     */
    @Override
    public int getLoanPeriodDays() {
        return STANDARD_LOAN_DAYS;
    }

    /**
     * Demonstrates Polymorphism: Magazines carry a higher overdue fine of £1.00 per day.
     *
     * @param daysOverdue the number of days overdue
     * @return calculated fine amount in £
     */
    @Override
    public double calculateFine(int daysOverdue) {
        if (daysOverdue <= 0) {
            return 0.0;
        }
        return daysOverdue * DAILY_FINE_RATE;
    }

    /**
     * Returns "Magazine" as the item type.
     *
     * @return "Magazine"
     */
    @Override
    public String getItemType() {
        return "Magazine";
    }

    @Override
    public String toString() {
        return "ISSN: " + getId() + ", Title: " + getTitle() + ", Issue: " + issueNumber + ", Publisher: " + publisher;
    }
}
