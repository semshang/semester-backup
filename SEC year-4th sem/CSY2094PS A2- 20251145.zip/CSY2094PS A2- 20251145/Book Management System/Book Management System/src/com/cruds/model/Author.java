package com.cruds.model;

/**
 * Represents an author in the Library Management System.
 */
public class Author {
	
	private String name;
	private String email;
	private String book_isbn;
	
	/**
	 * Constructs a new Author.
	 * @param name the author's name
	 * @param email the author's email
	 * @param book_isbn the ISBN of the book they authored
	 */
	public Author(String name, String email, String book_isbn) {
		this.name = name;
		this.email = email;
		this.book_isbn = book_isbn;
	}

	/**
	 * Gets the author's name.
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the author's name.
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the author's email.
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the author's email.
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Gets the associated book ISBN.
	 * @return the ISBN
	 */
	public String getBook_isbn() {
		return book_isbn;
	}

	/**
	 * Sets the associated book ISBN.
	 * @param book_isbn the ISBN to set
	 */
	public void setBook_isbn(String book_isbn) {
		this.book_isbn = book_isbn;
	}

	@Override
	public String toString() {
		return "" + name + "\t" + email + "\t" + book_isbn;
	}
}
