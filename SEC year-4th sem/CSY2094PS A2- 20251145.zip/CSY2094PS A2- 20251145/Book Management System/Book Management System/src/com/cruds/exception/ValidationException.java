package com.cruds.exception;

/**
 * Exception thrown when input data validation fails.
 */
public class ValidationException extends LibraryException {

    /**
     * Constructs a new ValidationException with the specified message.
     * @param message the detail message
     */
    public ValidationException(String message) {
        super(message);
    }
}
