package com.cruds.model;

/**
 * Abstract base class representing a generic library item (e.g., Book, Magazine).
 * Demonstrates Abstraction and serves as the root of the library item hierarchy,
 * enforcing common identity, metadata, and polymorphic loan period and fine calculations.
 */
public abstract class LibraryItem implements Persistable {
    private String id;
    private String title;

    /**
     * Constructs a new LibraryItem.
     *
     * @param id the unique identifier for the item (e.g. ISBN or ISSN)
     * @param title the title of the item
     */
    public LibraryItem(String id, String title) {
        this.id = id;
        this.title = title;
    }

    @Override
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets the title of the library item.
     *
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Polymorphic method: returns the standard loan duration for this item type in days.
     *
     * @return standard loan period in days
     */
    public abstract int getLoanPeriodDays();

    /**
     * Polymorphic method: calculates overdue fine for this item based on days overdue.
     * Different item types apply different fine rates.
     *
     * @param daysOverdue the number of days past the return due date
     * @return the total fine due in pounds (\u00A3)
     */
    public abstract double calculateFine(int daysOverdue);

    /**
     * Returns the human-readable item type classification (e.g., "Book", "Magazine").
     *
     * @return item type description
     */
    public abstract String getItemType();
}
