package com.cruds.db;

import com.cruds.exception.LibraryException;
import com.cruds.model.Author;
import com.cruds.model.Book;
import com.cruds.model.Issue;
import com.cruds.model.Student;
import com.cruds.util.DBConnectionManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.TimeUnit;
import javax.swing.table.DefaultTableModel;

/**
 * Data Access Object (DAO) for Book, Student, Author, and Issue records.
 * Provides complete CRUD operations, transactional book issuing and returning,
 * and reporting utilities using JDBC PreparedStatements.
 */
public class BookDAO {

	/**
	 * Adds a new book record to the database.
	 *
	 * @param book the Book to insert
	 * @return true if inserted successfully, false otherwise
	 * @throws LibraryException if a database error occurs
	 */
	public boolean addBook(Book book) {
		String sql = "insert into book(book_isbn, book_title, category, no_of_books) values(?, ?, ?, ?)";
		int rows = 0;

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, book.getIsbn());
			ps.setString(2, book.getTitle());
			ps.setString(3, book.getCategory());
			ps.setInt(4, book.getQuantity());

			rows = ps.executeUpdate();
		} catch (SQLException e) {
			throw new LibraryException("Database error occurred while adding book.", e);
		}

		return rows > 0;
	}

	/**
	 * Adds an author record associated with a book ISBN.
	 *
	 * @param author the Author to insert
	 * @return true if inserted successfully, false otherwise
	 * @throws LibraryException if a database error occurs
	 */
	public boolean addAuthor(Author author) {
		String sql = "insert into author(author_name, author_mail_id, book_isbn) values(?, ?, ?)";
		int rows = 0;

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, author.getName());
			ps.setString(2, author.getEmail());
			ps.setString(3, author.getBook_isbn());

			rows = ps.executeUpdate();
		} catch (SQLException e) {
			throw new LibraryException("Database error occurred while adding author.", e);
		}

		return rows > 0;
	}

	/**
	 * Updates an existing book and its author details.
	 *
	 * @param book the updated Book details
	 * @param author the updated Author details (can be null if not updating author)
	 * @return true if updated successfully
	 * @throws LibraryException if a database error occurs
	 */
	public boolean updateBook(Book book, Author author) {
		String sqlBook = "UPDATE book SET book_title = ?, category = ?, no_of_books = ? WHERE book_isbn = ?";
		String sqlCheckAuthor = "SELECT COUNT(*) FROM author WHERE book_isbn = ?";
		String sqlUpdateAuthor = "UPDATE author SET author_name = ?, author_mail_id = ? WHERE book_isbn = ?";
		String sqlInsertAuthor = "INSERT INTO author (author_name, author_mail_id, book_isbn) VALUES (?, ?, ?)";

		try (Connection conn = DBConnectionManager.getConnection()) {
			conn.setAutoCommit(false);
			try {
				// Update book
				try (PreparedStatement psBook = conn.prepareStatement(sqlBook)) {
					psBook.setString(1, book.getTitle());
					psBook.setString(2, book.getCategory());
					psBook.setInt(3, book.getQuantity());
					psBook.setString(4, book.getIsbn());
					int affected = psBook.executeUpdate();
					if (affected == 0) {
						conn.rollback();
						return false;
					}
				}

				// Update or insert author if provided
				if (author != null) {
					boolean authorExists = false;
					try (PreparedStatement psCheck = conn.prepareStatement(sqlCheckAuthor)) {
						psCheck.setString(1, book.getIsbn());
						try (ResultSet rs = psCheck.executeQuery()) {
							if (rs.next() && rs.getInt(1) > 0) {
								authorExists = true;
							}
						}
					}

					if (authorExists) {
						try (PreparedStatement psAuthor = conn.prepareStatement(sqlUpdateAuthor)) {
							psAuthor.setString(1, author.getName());
							psAuthor.setString(2, author.getEmail());
							psAuthor.setString(3, book.getIsbn());
							psAuthor.executeUpdate();
						}
					} else {
						try (PreparedStatement psAuthor = conn.prepareStatement(sqlInsertAuthor)) {
							psAuthor.setString(1, author.getName());
							psAuthor.setString(2, author.getEmail());
							psAuthor.setString(3, book.getIsbn());
							psAuthor.executeUpdate();
						}
					}
				}

				conn.commit();
				return true;
			} catch (SQLException ex) {
				conn.rollback();
				throw ex;
			} finally {
				conn.setAutoCommit(true);
			}
		} catch (SQLException e) {
			throw new LibraryException("Database error occurred while updating book: " + e.getMessage(), e);
		}
	}

	/**
	 * Updates book details without modifying author.
	 *
	 * @param book the Book to update
	 * @return true if updated successfully
	 * @throws LibraryException if a database error occurs
	 */
	public boolean updateBook(Book book) {
		return updateBook(book, null);
	}

	/**
	 * Deletes a book and its author details from the database.
	 * Fails with an exception if any copy of the book is currently issued.
	 *
	 * @param isbn the ISBN of the book to delete
	 * @return true if deleted successfully
	 * @throws LibraryException if book has active issues or database error occurs
	 */
	public boolean deleteBook(String isbn) {
		String sqlCheckIssued = "SELECT COUNT(*) FROM book_issue WHERE book_isbn = ?";
		String sqlDeleteAuthor = "DELETE FROM author WHERE book_isbn = ?";
		String sqlDeleteBook = "DELETE FROM book WHERE book_isbn = ?";

		try (Connection conn = DBConnectionManager.getConnection()) {
			// First verify no active loans exist for this book
			try (PreparedStatement psCheck = conn.prepareStatement(sqlCheckIssued)) {
				psCheck.setString(1, isbn);
				try (ResultSet rs = psCheck.executeQuery()) {
					if (rs.next() && rs.getInt(1) > 0) {
						throw new LibraryException("Cannot delete book (ISBN " + isbn + "): "
								+ rs.getInt(1) + " copy/copies are currently issued. Return them first.");
					}
				}
			}

			// Atomic deletion in transaction
			conn.setAutoCommit(false);
			try {
				try (PreparedStatement psAuthor = conn.prepareStatement(sqlDeleteAuthor)) {
					psAuthor.setString(1, isbn);
					psAuthor.executeUpdate();
				}

				int rows;
				try (PreparedStatement psBook = conn.prepareStatement(sqlDeleteBook)) {
					psBook.setString(1, isbn);
					rows = psBook.executeUpdate();
				}

				conn.commit();
				return rows > 0;
			} catch (SQLException ex) {
				conn.rollback();
				throw ex;
			} finally {
				conn.setAutoCommit(true);
			}
		} catch (SQLException e) {
			throw new LibraryException("Database error occurred while deleting book: " + e.getMessage(), e);
		}
	}

	/**
	 * Retrieves a single book by its ISBN.
	 *
	 * @param isbn the ISBN of the book
	 * @return the Book instance, or null if not found
	 * @throws LibraryException if a database error occurs
	 */
	public Book getBook(String isbn) {
		String sql = "SELECT book_isbn, book_title, category, no_of_books FROM book WHERE book_isbn = ?";
		try (Connection conn = DBConnectionManager.getConnection();
			 PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, isbn);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					return new Book(rs.getString("book_isbn"), rs.getString("book_title"),
							rs.getString("category"), rs.getInt("no_of_books"));
				}
			}
		} catch (SQLException e) {
			throw new LibraryException("Database error occurred while fetching book.", e);
		}
		return null;
	}

	/**
	 * Retrieves the author details associated with a book ISBN.
	 *
	 * @param isbn the book ISBN
	 * @return Author object, or null if not found
	 * @throws LibraryException if a database error occurs
	 */
	public Author getAuthor(String isbn) {
		String sql = "SELECT author_name, author_mail_id, book_isbn FROM author WHERE book_isbn = ?";
		try (Connection conn = DBConnectionManager.getConnection();
			 PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, isbn);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					return new Author(rs.getString("author_name"), rs.getString("author_mail_id"), rs.getString("book_isbn"));
				}
			}
		} catch (SQLException e) {
			throw new LibraryException("Database error occurred while fetching author.", e);
		}
		return null;
	}

	/**
	 * Adds a new student record to the database.
	 *
	 * @param stud the Student to insert
	 * @return true if inserted successfully
	 * @throws LibraryException if a database error occurs
	 */
	public boolean addStudent(Student stud) {
		String sql = "insert into student(usn, name) values(?, ?)";
		int rows = 0;

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, stud.getUsn());
			ps.setString(2, stud.getName());

			rows = ps.executeUpdate();
		} catch (SQLException e) {
			throw new LibraryException("Database error occurred while adding student.", e);
		}

		return rows > 0;
	}

	/**
	 * Updates an existing student record in the database.
	 *
	 * @param stud the updated Student object
	 * @return true if updated successfully
	 * @throws LibraryException if a database error occurs
	 */
	public boolean updateStudent(Student stud) {
		String sql = "UPDATE student SET name = ? WHERE usn = ?";
		int rows = 0;

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, stud.getName());
			ps.setString(2, stud.getUsn());

			rows = ps.executeUpdate();
		} catch (SQLException e) {
			throw new LibraryException("Database error occurred while updating student.", e);
		}

		return rows > 0;
	}

	/**
	 * Deletes a student from the database.
	 * Fails with an exception if the student currently has issued books.
	 *
	 * @param usn the student USN
	 * @return true if deleted successfully
	 * @throws LibraryException if student has active book loans or database error occurs
	 */
	public boolean deleteStudent(String usn) {
		String sqlCheckIssued = "SELECT COUNT(*) FROM book_issue WHERE usn = ?";
		String sqlDelete = "DELETE FROM student WHERE usn = ?";

		try (Connection conn = DBConnectionManager.getConnection()) {
			try (PreparedStatement psCheck = conn.prepareStatement(sqlCheckIssued)) {
				psCheck.setString(1, usn);
				try (ResultSet rs = psCheck.executeQuery()) {
					if (rs.next() && rs.getInt(1) > 0) {
						throw new LibraryException("Cannot delete student (" + usn + "): "
								+ rs.getInt(1) + " book(s) currently issued to this student. Return them first.");
					}
				}
			}

			int rows;
			try (PreparedStatement ps = conn.prepareStatement(sqlDelete)) {
				ps.setString(1, usn);
				rows = ps.executeUpdate();
			}
			return rows > 0;
		} catch (SQLException e) {
			throw new LibraryException("Database error occurred while deleting student: " + e.getMessage(), e);
		}
	}

	/**
	 * Retrieves a student by USN.
	 *
	 * @param usn the USN
	 * @return Student object or null
	 * @throws LibraryException if database error occurs
	 */
	public Student getStudent(String usn) {
		String sql = "SELECT usn, name FROM student WHERE usn = ?";
		try (Connection conn = DBConnectionManager.getConnection();
			 PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, usn);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					return new Student(rs.getString("usn"), rs.getString("name"));
				}
			}
		} catch (SQLException e) {
			throw new LibraryException("Database error occurred while fetching student.", e);
		}
		return null;
	}

	/**
	 * Checks if a student exists in the database.
	 *
	 * @param stud Student to check
	 * @return true if student exists
	 */
	public boolean studentExist(Student stud) {
		String sql = "select usn, name from student where usn = ?";
		boolean flag = false;

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, stud.getUsn());
			ResultSet rs = ps.executeQuery();
			if (rs != null && rs.next()) {
				flag = true;
			}
		} catch (SQLException e) {
			throw new LibraryException("Database error occurred.", e);
		}

		return flag;
	}

	/**
	 * Searches students by USN.
	 *
	 * @param usn student USN
	 * @return DefaultTableModel for UI display
	 */
	public DefaultTableModel getStudentbyUsn(String usn) {
		String sql = "select usn, name from student where LOWER(usn) = ?";
		Vector<String> colNames = new Vector<>();
		colNames.add("USN");
		colNames.add("Name");

		Vector<Vector<String>> data = new Vector<>();

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, usn.toLowerCase());

			ResultSet rs = ps.executeQuery();
			while (rs != null && rs.next()) {
				Vector<String> row = new Vector<>();
				row.add(rs.getString(1));
				row.add(rs.getString(2));
				data.add(row);
			}

		} catch (SQLException e) {
			throw new LibraryException("Database error occurred.", e);
		}
		return new DefaultTableModel(data, colNames);
	}

	/**
	 * Searches students by Name.
	 *
	 * @param name student name
	 * @return DefaultTableModel for UI display
	 */
	public DefaultTableModel getStudentbyName(String name) {
		String sql = "select usn, name from student where LOWER(name) = ?";
		Vector<String> colNames = new Vector<>();
		colNames.add("USN");
		colNames.add("Name");

		Vector<Vector<String>> data = new Vector<>();

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, name.toLowerCase());

			ResultSet rs = ps.executeQuery();
			while (rs != null && rs.next()) {
				Vector<String> row = new Vector<>();
				row.add(rs.getString(1));
				row.add(rs.getString(2));
				data.add(row);
			}

		} catch (SQLException e) {
			throw new LibraryException("Database error occurred.", e);
		}
		return new DefaultTableModel(data, colNames);
	}

	/**
	 * Lists all students in the database.
	 *
	 * @return DefaultTableModel of all students
	 */
	public DefaultTableModel getAllStudents() {
		String sql = "SELECT usn, name FROM student ORDER BY name ASC";
		Vector<String> colNames = new Vector<>();
		colNames.add("USN");
		colNames.add("Name");

		Vector<Vector<String>> data = new Vector<>();

		try (Connection conn = DBConnectionManager.getConnection();
			 PreparedStatement ps = conn.prepareStatement(sql);
			 ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				Vector<String> row = new Vector<>();
				row.add(rs.getString(1));
				row.add(rs.getString(2));
				data.add(row);
			}
		} catch (SQLException e) {
			throw new LibraryException("Database error occurred while fetching all students.", e);
		}
		return new DefaultTableModel(data, colNames);
	}

	/**
	 * Searches books by Title substring.
	 *
	 * @param title book title keyword
	 * @return DefaultTableModel with matching books
	 */
	public DefaultTableModel getByTitle(String title) {
		String sql = "select b.book_isbn, b.book_title, b.category, b.no_of_books, a.author_name "
				+ "from book b left join author a on a.book_isbn = b.book_isbn where LOWER(b.book_title) like ? ";
		Vector<String> colNames = new Vector<>();
		colNames.add("Book ISBN");
		colNames.add("Book Title");
		colNames.add("Category");
		colNames.add("Quantity");
		colNames.add("Author");

		Vector<Vector<String>> data = new Vector<>();

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, "%" + title.toLowerCase() + "%");

			ResultSet rs = ps.executeQuery();
			while (rs != null && rs.next()) {
				Vector<String> row = new Vector<>();
				row.add(rs.getString(1));
				row.add(rs.getString(2));
				row.add(rs.getString(3));
				row.add(String.valueOf(rs.getInt(4)));
				row.add(rs.getString(5) != null ? rs.getString(5) : "-");
				data.add(row);
			}

		} catch (SQLException e) {
			throw new LibraryException("Database error occurred.", e);
		}
		return new DefaultTableModel(data, colNames);
	}

	/**
	 * Searches books by Category substring.
	 *
	 * @param category category keyword
	 * @return DefaultTableModel with matching books
	 */
	public DefaultTableModel getByCategory(String category) {
		String sql = "select b.book_isbn, b.book_title, b.category, b.no_of_books, a.author_name "
				+ "from book b left join author a on a.book_isbn = b.book_isbn where LOWER(b.category) like ?";
		Vector<String> colNames = new Vector<>();
		colNames.add("Book ISBN");
		colNames.add("Book Title");
		colNames.add("Category");
		colNames.add("Quantity");
		colNames.add("Author");

		Vector<Vector<String>> data = new Vector<>();

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, "%" + category.toLowerCase() + "%");
			ResultSet rs = ps.executeQuery();

			while (rs != null && rs.next()) {
				Vector<String> row = new Vector<>();
				row.add(rs.getString(1));
				row.add(rs.getString(2));
				row.add(rs.getString(3));
				row.add(String.valueOf(rs.getInt(4)));
				row.add(rs.getString(5) != null ? rs.getString(5) : "-");
				data.add(row);
			}

		} catch (SQLException e) {
			throw new LibraryException("Database error occurred.", e);
		}
		return new DefaultTableModel(data, colNames);
	}

	/**
	 * Searches books by Author name substring.
	 *
	 * @param name author name keyword
	 * @return DefaultTableModel with matching books
	 */
	public DefaultTableModel getByAuthor(String name) {
		String sql = "select b.book_isbn, b.book_title, b.category, b.no_of_books, a.author_name "
				+ "from book b inner join author a on b.book_isbn = a.book_isbn where LOWER(a.author_name) like ?";
		Vector<String> colNames = new Vector<>();
		colNames.add("Book ISBN");
		colNames.add("Book Title");
		colNames.add("Category");
		colNames.add("Quantity");
		colNames.add("Author");

		Vector<Vector<String>> data = new Vector<>();

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, "%" + name.toLowerCase() + "%");
			ResultSet rs = ps.executeQuery();

			while (rs != null && rs.next()) {
				Vector<String> row = new Vector<>();
				row.add(rs.getString(1));
				row.add(rs.getString(2));
				row.add(rs.getString(3));
				row.add(String.valueOf(rs.getInt(4)));
				row.add(rs.getString(5) != null ? rs.getString(5) : "-");
				data.add(row);
			}

		} catch (SQLException e) {
			throw new LibraryException("Database error occurred.", e);
		}
		return new DefaultTableModel(data, colNames);
	}

	/**
	 * Searches books by exact ISBN.
	 *
	 * @param isbn book ISBN
	 * @return DefaultTableModel with matching book
	 */
	public DefaultTableModel getByIsbn(String isbn) {
		String sql = "select b.book_isbn, b.book_title, b.category, b.no_of_books, a.author_name "
				+ "from book b left join author a on a.book_isbn = b.book_isbn where LOWER(b.book_isbn) = ?";
		Vector<String> colNames = new Vector<>();
		colNames.add("Book ISBN");
		colNames.add("Book Title");
		colNames.add("Category");
		colNames.add("Quantity");
		colNames.add("Author");

		Vector<Vector<String>> data = new Vector<>();

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, isbn.toLowerCase());
			ResultSet rs = ps.executeQuery();

			while (rs != null && rs.next()) {
				Vector<String> row = new Vector<>();
				row.add(rs.getString(1));
				row.add(rs.getString(2));
				row.add(rs.getString(3));
				row.add(String.valueOf(rs.getInt(4)));
				row.add(rs.getString(5) != null ? rs.getString(5) : "-");
				data.add(row);
			}

		} catch (SQLException e) {
			throw new LibraryException("Database error occurred.", e);
		}
		return new DefaultTableModel(data, colNames);
	}

	/**
	 * Retrieves all books along with author details.
	 *
	 * @return DefaultTableModel containing all books and authors
	 */
	public DefaultTableModel getTableBookAuthor() {
		String sql = "select b.book_isbn, b.book_title, b.category, b.no_of_books, a.author_name "
				+ "from book b left join author a on a.book_isbn = b.book_isbn";
		Vector<String> colNames = new Vector<>();
		colNames.add("Book ISBN");
		colNames.add("Book Title");
		colNames.add("Category");
		colNames.add("Quantity");
		colNames.add("Author");

		Vector<Vector<String>> data = new Vector<>();

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			while (rs != null && rs.next()) {
				Vector<String> row = new Vector<>();
				row.add(rs.getString(1));
				row.add(rs.getString(2));
				row.add(rs.getString(3));
				row.add(String.valueOf(rs.getInt(4)));
				row.add(rs.getString(5) != null ? rs.getString(5) : "-");
				data.add(row);
			}

		} catch (SQLException e) {
			throw new LibraryException("Database error occurred.", e);
		}
		return new DefaultTableModel(data, colNames);
	}

	/**
	 * Issues a book to a student wrapped in a strict JDBC Transaction.
	 * Atomically verifies stock > 0, decrements available book count, and records the loan.
	 * Performs rollback if any step fails.
	 *
	 * @param bi Issue loan record details
	 * @return true if book was successfully issued
	 * @throws LibraryException on database error or transaction rollback
	 */
	public boolean issueBook(Issue bi) {
		String sqlCheckStock = "SELECT no_of_books FROM book WHERE book_isbn = ?";
		String sqlUpdateStock = "UPDATE book SET no_of_books = no_of_books - 1 WHERE book_isbn = ? AND no_of_books > 0";
		String sqlInsertIssue = "INSERT INTO book_issue(issue_id, usn, issue_date, return_date, book_isbn) VALUES(?, ?, ?, ?, ?)";

		java.sql.Date idate = new java.sql.Date(bi.getIssueDate().getTime());
		java.sql.Date rdate = new java.sql.Date(bi.getReturnDate().getTime());

		try (Connection conn = DBConnectionManager.getConnection()) {
			conn.setAutoCommit(false);
			try {
				// 1. Verify availability
				try (PreparedStatement psCheck = conn.prepareStatement(sqlCheckStock)) {
					psCheck.setString(1, bi.getBook_isbn());
					try (ResultSet rs = psCheck.executeQuery()) {
						if (!rs.next()) {
							conn.rollback();
							throw new LibraryException("Book with ISBN " + bi.getBook_isbn() + " does not exist.");
						}
						int available = rs.getInt(1);
						if (available <= 0) {
							conn.rollback();
							throw new LibraryException("Book is out of stock (available: 0).");
						}
					}
				}

				// 2. Decrement stock
				int rowsCount;
				try (PreparedStatement psCount = conn.prepareStatement(sqlUpdateStock)) {
					psCount.setString(1, bi.getBook_isbn());
					rowsCount = psCount.executeUpdate();
					if (rowsCount == 0) {
						conn.rollback();
						throw new LibraryException("Failed to decrement book stock. Copy may no longer be available.");
					}
				}

				// 3. Insert issue record
				int rowsIssue;
				try (PreparedStatement ps = conn.prepareStatement(sqlInsertIssue)) {
					ps.setInt(1, bi.getId());
					ps.setString(2, bi.getUsn());
					ps.setDate(3, idate);
					ps.setDate(4, rdate);
					ps.setString(5, bi.getBook_isbn());
					rowsIssue = ps.executeUpdate();
					if (rowsIssue == 0) {
						conn.rollback();
						throw new LibraryException("Failed to create issue record.");
					}
				}

				// 4. Commit transaction
				conn.commit();
				return true;
			} catch (SQLException ex) {
				conn.rollback();
				throw new LibraryException("Failed to issue book: transaction rolled back. " + ex.getMessage(), ex);
			} finally {
				conn.setAutoCommit(true);
			}
		} catch (SQLException e) {
			throw new LibraryException("Database connection error during book issue: " + e.getMessage(), e);
		}
	}

	/**
	 * Returns an issued book wrapped in a strict JDBC Transaction.
	 * Atomically removes the issue record and increments the available book quantity.
	 * Performs rollback if any step fails.
	 *
	 * @param id the issue_id to return
	 * @param isbn the book ISBN
	 * @return true if book was returned successfully
	 * @throws LibraryException on database error or transaction rollback
	 */
	public boolean returnBook(int id, String isbn) {
		String sqlDeleteIssue = "DELETE FROM book_issue WHERE issue_id = ?";
		String sqlUpdateStock = "UPDATE book SET no_of_books = no_of_books + 1 WHERE book_isbn = ?";

		try (Connection conn = DBConnectionManager.getConnection()) {
			conn.setAutoCommit(false);
			try {
				// 1. Delete issue record
				int rowsDelete;
				try (PreparedStatement ps = conn.prepareStatement(sqlDeleteIssue)) {
					ps.setInt(1, id);
					rowsDelete = ps.executeUpdate();
					if (rowsDelete == 0) {
						conn.rollback();
						throw new LibraryException("Issue record ID " + id + " not found or already returned.");
					}
				}

				// 2. Increment stock count
				int rowsStock;
				try (PreparedStatement psCount = conn.prepareStatement(sqlUpdateStock)) {
					psCount.setString(1, isbn);
					rowsStock = psCount.executeUpdate();
					if (rowsStock == 0) {
						conn.rollback();
						throw new LibraryException("Failed to update stock for ISBN " + isbn);
					}
				}

				// 3. Commit transaction
				conn.commit();
				return true;
			} catch (SQLException ex) {
				conn.rollback();
				throw new LibraryException("Failed to return book: transaction rolled back. " + ex.getMessage(), ex);
			} finally {
				conn.setAutoCommit(true);
			}
		} catch (SQLException e) {
			throw new LibraryException("Database connection error during book return: " + e.getMessage(), e);
		}
	}

	/**
	 * Lists issued books for a specific student USN.
	 *
	 * @param usn student USN
	 * @return DefaultTableModel of issued books
	 */
	public DefaultTableModel listBookByUsn(String usn) {
		String sql = "select bi.issue_id, b.book_title, bi.usn, s.name, bi.issue_date, bi.return_date, bi.book_isbn "
				+ "from book b, student s, book_issue bi where b.book_isbn = bi.book_isbn and bi.usn = s.usn and LOWER(bi.usn) = ?";
		Vector<String> colNames = new Vector<>();
		colNames.add("ID");
		colNames.add("Book Title");
		colNames.add("USN");
		colNames.add("Student Name");
		colNames.add("Issue Date");
		colNames.add("Return Date");
		colNames.add("ISBN");

		Vector<Vector<String>> data = new Vector<>();

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, usn.toLowerCase());
			ResultSet rs = ps.executeQuery();

			while (rs != null && rs.next()) {
				Vector<String> row = new Vector<>();
				row.add(String.valueOf(rs.getInt(1)));
				row.add(rs.getString(2));
				row.add(rs.getString(3));
				row.add(rs.getString(4));
				row.add(String.valueOf(rs.getDate(5)));
				row.add(String.valueOf(rs.getDate(6)));
				row.add(rs.getString(7));
				data.add(row);
			}

		} catch (SQLException e) {
			throw new LibraryException("Database error occurred.", e);
		}

		return new DefaultTableModel(data, colNames);
	}

	/**
	 * Lists all currently issued books across all students.
	 *
	 * @return DefaultTableModel of all issued books
	 */
	public DefaultTableModel listIssuedBooks() {
		String sql = "select bi.issue_id, b.book_title, bi.usn, s.name, bi.issue_date, bi.return_date, bi.book_isbn "
				+ "from book b, student s, book_issue bi where b.book_isbn = bi.book_isbn and bi.usn = s.usn";
		Vector<String> colNames = new Vector<>();
		colNames.add("ID");
		colNames.add("Book Title");
		colNames.add("USN");
		colNames.add("Student Name");
		colNames.add("Issue Date");
		colNames.add("Return Date");
		colNames.add("ISBN");

		Vector<Vector<String>> data = new Vector<>();

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			while (rs != null && rs.next()) {
				Vector<String> row = new Vector<>();
				row.add(String.valueOf(rs.getInt(1)));
				row.add(rs.getString(2));
				row.add(rs.getString(3));
				row.add(rs.getString(4));
				row.add(String.valueOf(rs.getDate(5)));
				row.add(String.valueOf(rs.getDate(6)));
				row.add(rs.getString(7));
				data.add(row);
			}

		} catch (SQLException e) {
			throw new LibraryException("Database error occurred.", e);
		}
		return new DefaultTableModel(data, colNames);
	}

	/**
	 * Gets books whose return date equals a specific date.
	 *
	 * @param curDate the reference date
	 * @return DefaultTableModel with matching books
	 */
	public DefaultTableModel getBookToReturn(Date curDate) {
		String sql = "select bi.issue_id, b.book_title, bi.usn, s.name, bi.issue_date, bi.return_date, bi.book_isbn "
				+ "from book b, student s, book_issue bi where b.book_isbn = bi.book_isbn and bi.usn = s.usn and bi.return_date = ?";
		Vector<String> colNames = new Vector<>();
		colNames.add("ID");
		colNames.add("Book Title");
		colNames.add("USN");
		colNames.add("Student Name");
		colNames.add("Issue Date");
		colNames.add("Return Date");
		colNames.add("ISBN");

		Vector<Vector<String>> data = new Vector<>();
		java.sql.Date cdate = new java.sql.Date(curDate.getTime());

		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setDate(1, cdate);
			ResultSet rs = ps.executeQuery();

			while (rs != null && rs.next()) {
				Vector<String> row = new Vector<>();
				row.add(String.valueOf(rs.getInt(1)));
				row.add(rs.getString(2));
				row.add(rs.getString(3));
				row.add(rs.getString(4));
				row.add(String.valueOf(rs.getDate(5)));
				row.add(String.valueOf(rs.getDate(6)));
				row.add(rs.getString(7));
				data.add(row);
			}

		} catch (SQLException e) {
			throw new LibraryException("Database error occurred.", e);
		}

		return new DefaultTableModel(data, colNames);
	}

	/**
	 * Retrieves all overdue book loans where return_date &lt; curDate.
	 * Calculates overdue days and fine amount per loan record.
	 *
	 * @param curDate the current date
	 * @param dailyFineRate fine amount per overdue day (e.g. £1.00)
	 * @return DefaultTableModel with overdue details and fines
	 */
	public DefaultTableModel getOverdueBooks(Date curDate, double dailyFineRate) {
		String sql = "SELECT bi.issue_id, b.book_title, bi.usn, s.name, bi.issue_date, bi.return_date, bi.book_isbn "
				+ "FROM book b, student s, book_issue bi "
				+ "WHERE b.book_isbn = bi.book_isbn AND bi.usn = s.usn AND bi.return_date < ? "
				+ "ORDER BY bi.return_date ASC";

		Vector<String> colNames = new Vector<>();
		colNames.add("Issue ID");
		colNames.add("Book Title");
		colNames.add("Student USN");
		colNames.add("Student Name");
		colNames.add("Issue Date");
		colNames.add("Due Date");
		colNames.add("Days Overdue");
		colNames.add("Fine Due (\u00A3)");
		colNames.add("ISBN");

		Vector<Vector<String>> data = new Vector<>();
		java.sql.Date cdate = new java.sql.Date(curDate.getTime());

		try (Connection conn = DBConnectionManager.getConnection();
			 PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setDate(1, cdate);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					Vector<String> row = new Vector<>();
					int issueId = rs.getInt(1);
					String bookTitle = rs.getString(2);
					String usn = rs.getString(3);
					String studentName = rs.getString(4);
					java.sql.Date issueDate = rs.getDate(5);
					java.sql.Date dueDate = rs.getDate(6);
					String isbn = rs.getString(7);

					long diffMillis = curDate.getTime() - dueDate.getTime();
					long daysOverdue = TimeUnit.DAYS.convert(diffMillis, TimeUnit.MILLISECONDS);
					if (daysOverdue < 0) daysOverdue = 0;

					double fine = daysOverdue * dailyFineRate;

					row.add(String.valueOf(issueId));
					row.add(bookTitle);
					row.add(usn);
					row.add(studentName);
					row.add(String.valueOf(issueDate));
					row.add(String.valueOf(dueDate));
					row.add(String.valueOf(daysOverdue));
					row.add(String.format("%.2f", fine));
					row.add(isbn);

					data.add(row);
				}
			}
		} catch (SQLException e) {
			throw new LibraryException("Database error occurred while fetching overdue books.", e);
		}

		return new DefaultTableModel(data, colNames);
	}

	/**
	 * Counts the number of currently overdue book loans.
	 *
	 * @return total overdue count
	 */
	public int getOverdueCount() {
		String sql = "SELECT COUNT(*) FROM book_issue WHERE return_date < CURRENT_DATE()";
		try (Connection conn = DBConnectionManager.getConnection();
			 PreparedStatement ps = conn.prepareStatement(sql);
			 ResultSet rs = ps.executeQuery()) {
			if (rs.next()) {
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new LibraryException("Database error occurred while checking overdue count.", e);
		}
		return 0;
	}

	/**
	 * Retrieves distinct book categories for dropdown selection.
	 *
	 * @return array of category strings
	 */
	public String[] getAllCategory() {
		String sql = "Select distinct category from book order by category";
		List<String> list = new ArrayList<>();
		list.add("Select");
		try (Connection conn = DBConnectionManager.getConnection()) {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			while (rs != null && rs.next()) {
				String cat = rs.getString(1);
				if (cat != null && !cat.trim().isEmpty()) {
					list.add(cat);
				}
			}

		} catch (SQLException ex) {
			throw new LibraryException("Database error occurred.", ex);
		}

		return list.toArray(new String[0]);
	}
}
