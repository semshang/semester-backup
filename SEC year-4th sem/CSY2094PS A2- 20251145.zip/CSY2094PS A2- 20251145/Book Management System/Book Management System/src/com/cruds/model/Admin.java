package com.cruds.model;

/**
 * Represents an administrator in the Library Management System.
 */
public class Admin extends UserAccount {
    private String password;
    
    /**
     * Constructs a new Admin with the specified credentials.
     * @param id the unique administrator ID
     * @param password the administrator's password
     */
    public Admin(String id, String password) {
        super(id, "Administrator"); // Defaulting name for admin
        this.password = password;
    }
    
    /**
     * Gets the password of the administrator.
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password of the administrator.
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
