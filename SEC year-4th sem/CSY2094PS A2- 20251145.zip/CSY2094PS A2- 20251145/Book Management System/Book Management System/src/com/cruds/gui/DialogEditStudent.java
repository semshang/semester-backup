package com.cruds.gui;

import com.cruds.db.BookDAO;
import com.cruds.exception.LibraryException;
import com.cruds.exception.ValidationException;
import com.cruds.model.Student;
import com.cruds.util.ValidationUtil;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/**
 * Modal dialog for updating an existing Student's details.
 * Ensures USN is immutable and validates the updated student name.
 */
public class DialogEditStudent extends JDialog {

    private final String usn;
    private final BookDAO dao;
    private boolean updated = false;

    private JTextField txtUsn;
    private JTextField txtName;

    private final Color PRIMARY_BLUE = new Color(47, 128, 237);
    private final Color TEXT_DARK = new Color(45, 45, 45);
    private final Color BORDER_GRAY = new Color(229, 229, 229);

    public DialogEditStudent(Frame parent, String usn, String initialName) {
        super(parent, "Update Student", true);
        this.usn = usn;
        this.dao = new BookDAO();

        initComponents(initialName);
        pack();
        setLocationRelativeTo(parent);
    }

    private void initComponents(String initialName) {
        JPanel contentPane = new JPanel(new BorderLayout(15, 15));
        contentPane.setBackground(Color.WHITE);
        contentPane.setBorder(new EmptyBorder(20, 25, 20, 25));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        JLabel titleLabel = new JLabel("Update Student", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(TEXT_DARK);
        JLabel subtitleLabel = new JLabel("Edit details for USN: " + usn, SwingConstants.CENTER);
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitleLabel.setForeground(Color.GRAY);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        headerPanel.add(subtitleLabel, BorderLayout.SOUTH);
        contentPane.add(headerPanel, BorderLayout.NORTH);

        // Form Fields
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtUsn = new JTextField(usn);
        txtUsn.setEditable(false);
        txtUsn.setBackground(new Color(245, 245, 245));
        txtUsn.setPreferredSize(new Dimension(220, 32));
        txtUsn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtUsn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_GRAY),
                new EmptyBorder(4, 8, 4, 8)));

        txtName = new JTextField(initialName != null ? initialName : "");
        txtName.setPreferredSize(new Dimension(220, 32));
        txtName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtName.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_GRAY),
                new EmptyBorder(4, 8, 4, 8)));

        gbc.gridx = 0; gbc.gridy = 0;
        JLabel lblUsn = new JLabel("USN (Read-Only):");
        lblUsn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        formPanel.add(lblUsn, gbc);

        gbc.gridx = 1;
        formPanel.add(txtUsn, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        JLabel lblName = new JLabel("Student Name:");
        lblName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        formPanel.add(lblName, gbc);

        gbc.gridx = 1;
        formPanel.add(txtName, gbc);

        contentPane.add(formPanel, BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonPanel.setBackground(Color.WHITE);

        JButton btnCancel = new JButton("Cancel");
        btnCancel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnCancel.setFocusPainted(false);
        btnCancel.addActionListener(e -> dispose());

        JButton btnSave = new JButton("Save Changes");
        btnSave.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSave.setBackground(PRIMARY_BLUE);
        btnSave.setForeground(Color.WHITE);
        btnSave.setFocusPainted(false);
        btnSave.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSave.addActionListener(e -> onSave());

        buttonPanel.add(btnCancel);
        buttonPanel.add(btnSave);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);

        setContentPane(contentPane);
        setResizable(false);
    }

    private void onSave() {
        String name = txtName.getText().trim();
        try {
            ValidationUtil.validateName(name, "Student Name");
            Student stud = new Student(usn, name);
            boolean success = dao.updateStudent(stud);
            if (success) {
                JOptionPane.showMessageDialog(this, "Student updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                updated = true;
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update student.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (ValidationException ve) {
            JOptionPane.showMessageDialog(this, ve.getMessage(), "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (LibraryException le) {
            JOptionPane.showMessageDialog(this, "Database error: " + le.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isUpdated() {
        return updated;
    }
}
