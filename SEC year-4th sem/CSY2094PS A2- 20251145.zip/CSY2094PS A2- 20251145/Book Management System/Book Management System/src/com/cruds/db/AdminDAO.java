package com.cruds.db;

import com.cruds.model.Admin;
import com.cruds.util.DBConnectionManager;
import com.cruds.exception.LibraryException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Data Access Object for handling Admin database operations.
 */
public class AdminDAO {
    
    /**
     * Checks if the given admin credentials are valid in the database.
     * @param admin the admin containing credentials to check
     * @return true if valid, false otherwise
     * @throws LibraryException if a database error occurs
     */
    public boolean isValidAdmin(Admin admin) {
        String sql = "select admin_id, password from admin where admin_id = ? and password = ?";
        
        try(Connection conn = DBConnectionManager.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, admin.getId());
            ps.setString(2, admin.getPassword());
            ResultSet rs = ps.executeQuery();
            while(rs != null && rs.next()) {
                if(rs.getString(1).equals(admin.getId()) && rs.getString(2).equals(admin.getPassword())) {
                    return true;
                }
            }
        } catch (SQLException ex) {
            throw new LibraryException("Error validating admin credentials.", ex);
        }
        return false;
    }
}
