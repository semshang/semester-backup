package com.cruds.gui;

import com.cruds.db.BookDAO;
import com.cruds.exception.LibraryException;
import com.cruds.exception.ValidationException;
import com.cruds.model.Author;
import com.cruds.model.Book;
import com.cruds.model.Issue;
import com.cruds.model.Student;
import com.cruds.util.ValidationUtil;

import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

/**
 * Main application dashboard for the Library Management System.
 * Provides management of books, authors, students, loans, returns, and overdue reports.
 */
public class MainFrame extends JFrame {
    BookDAO dao = new BookDAO();
    String searchBy = null, searchBookBy = null;
    
    // UI Components
    private JPanel sidebarPanel, mainContentPanel, headerPanel, cardsPanel;
    private CardLayout cardLayout;
    
    // Sidebar Buttons
    private SidebarButton btnAddBook, btnSearchBook, btnListBooks, btnIssueBook, btnListIssuedBooks, btnReturnToday, btnOverdueBooks;
    private LogoutButton btnLogout;
    
    // Panels
    private JPanel panelAddBook, panelSearchBook, panelListBooks, panelIssueBook, panelIssuedBooks, panelReturnToday, panelOverdueBooks;
    
    // Elements of Add Book
    private JTextField txtISBN, txtTitle, txtCategory, txtAuthorName, txtAuthorEmail, txtQuantity;
    private JComboBox<String> comboBoxCategory;
    private JButton btnAdd;
    
    // Elements of Search Book
    private JTextField txtSearch;
    private JComboBox<String> comboBoxSearchBy;
    private JButton btnSearch;
    private JTable searchTable;
    
    // Elements of List Books
    private JTable bookAuthorTable;
    private JButton btnEditBook, btnDeleteBook, btnRefreshBooks;
    
    // Elements of Issue Book
    private JTextField txtSearchBook, txtUsnSearch;
    private JComboBox<String> ComboBoxSearchBook;
    private JButton btnSearchBookIssue, btnSearchBookIssue1, btnIssue, btnAddStudent;
    private JButton btnEditStudent, btnDeleteStudent, btnListAllStudents;
    private JTable bookTable, studentTable;
    
    // Elements of Issued Books
    private JTextField txtUsn;
    private JButton btnSearchByUsn, btnReturn;
    private JTable issuedBooksTable;
    
    // Elements of Return Today
    private JTable returnTodayTable;

    // Elements of Overdue Books
    private JTable overdueTable;
    private JLabel lblOverdueSummary;
    private JButton btnRefreshOverdue, btnReturnOverdue;
    
    // Styling Colors
    private final Color PRIMARY_BLUE = new Color(47, 128, 237); // #2F80ED
    private final Color TEXT_DARK = new Color(45, 45, 45); // #2D2D2D
    private final Color BORDER_GRAY = new Color(229, 229, 229); // #E5E5E5
    private final Color HOVER_BLUE = new Color(234, 244, 255); // #EAF4FF
    private final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 28);
    private final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 15);
    private final Font FONT_TABLE_HEADER = new Font("Segoe UI", Font.BOLD, 15);
    private final Font FONT_TABLE_CONTENT = new Font("Segoe UI", Font.PLAIN, 14);

    public MainFrame() {
        initializeComponents();
        createSidebar();
        createHeader();
        createCardsPanel();
        
        // Assemble Main Frame
        setLayout(new BorderLayout());
        add(sidebarPanel, BorderLayout.WEST);
        
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(headerPanel, BorderLayout.NORTH);
        
        mainContentPanel = new JPanel(new BorderLayout());
        mainContentPanel.setBackground(Color.WHITE);
        mainContentPanel.setBorder(new EmptyBorder(25, 25, 25, 25));
        mainContentPanel.add(cardsPanel, BorderLayout.CENTER);
        
        centerPanel.add(mainContentPanel, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);
        
        addEventListeners();
        
        // Set default view
        switchPanel("Add Book", btnAddBook);
    }
    
    private void createCardsPanel() {
        cardsPanel.add(panelAddBook, "Add Book");
        cardsPanel.add(panelSearchBook, "Search Book");
        cardsPanel.add(panelListBooks, "List Books");
        cardsPanel.add(panelIssueBook, "Issue Book");
        cardsPanel.add(panelIssuedBooks, "Issued Books");
        cardsPanel.add(panelReturnToday, "Return Today");
        cardsPanel.add(panelOverdueBooks, "Overdue Books");
    }
    
    private void initializeComponents() {
        setTitle("Library Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1420, 840);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.WHITE);
        
        cardLayout = new CardLayout();
        cardsPanel = new JPanel(cardLayout);
        cardsPanel.setBackground(Color.WHITE);
        
        initPanelAddBook();
        initPanelSearchBook();
        initPanelListBooks();
        initPanelIssueBook();
        initPanelIssuedBooks();
        initPanelReturnToday();
        initPanelOverdueBooks();
    }
    
    private void createSidebar() {
        sidebarPanel = new JPanel();
        sidebarPanel.setPreferredSize(new Dimension(260, 840));
        sidebarPanel.setBackground(Color.WHITE);
        sidebarPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, BORDER_GRAY));
        sidebarPanel.setLayout(new BoxLayout(sidebarPanel, BoxLayout.Y_AXIS));

        // Add Library Icon and Title
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 20));
        titlePanel.setBackground(Color.WHITE);
        titlePanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel lblBookIcon = new JLabel(new CustomIcon("book", PRIMARY_BLUE));
        JLabel lblTitle = new JLabel("<html>Library<br>Management</html>");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(TEXT_DARK);
        titlePanel.add(lblBookIcon);
        titlePanel.add(lblTitle);
        titlePanel.setMaximumSize(new Dimension(260, 100));

        sidebarPanel.add(titlePanel);
        sidebarPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Navigation Buttons
        btnAddBook = new SidebarButton("Add Book", "add");
        btnSearchBook = new SidebarButton("Search Book", "search");
        btnListBooks = new SidebarButton("List All Books", "list");
        btnIssueBook = new SidebarButton("Issue Book", "issue");
        btnListIssuedBooks = new SidebarButton("Return Book", "issued");
        btnReturnToday = new SidebarButton("Returns Today", "return");
        btnOverdueBooks = new SidebarButton("Overdue Books", "overdue");
        
        SidebarButton[] navButtons = { btnAddBook, btnSearchBook, btnListBooks, btnIssueBook, btnListIssuedBooks, btnReturnToday, btnOverdueBooks };
        
        for (SidebarButton btn : navButtons) {
            btn.setMaximumSize(new Dimension(230, 48));
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebarPanel.add(btn);
            sidebarPanel.add(Box.createRigidArea(new Dimension(0, 8)));
        }

        sidebarPanel.add(Box.createVerticalGlue());
        
        btnLogout = new LogoutButton();
        btnLogout.setMaximumSize(new Dimension(230, 48));
        btnLogout.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebarPanel.add(btnLogout);
        sidebarPanel.add(Box.createRigidArea(new Dimension(0, 20)));
    }
    
    private void createHeader() {
        headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        headerPanel.setBorder(new EmptyBorder(15, 30, 0, 30));
        headerPanel.setPreferredSize(new Dimension(1000, 60));
        
        JPanel rightHeader = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 0));
        rightHeader.setBackground(Color.WHITE);
        
        JLabel lblAdmin = new JLabel("Admin", new CustomIcon("user", PRIMARY_BLUE), SwingConstants.RIGHT);
        lblAdmin.setFont(FONT_BUTTON);
        lblAdmin.setForeground(TEXT_DARK);
        
        rightHeader.add(lblAdmin);
        headerPanel.add(rightHeader, BorderLayout.EAST);
    }
    
    private void switchPanel(String name, SidebarButton activeBtn) {
        cardLayout.show(cardsPanel, name);
        SidebarButton[] navButtons = { btnAddBook, btnSearchBook, btnListBooks, btnIssueBook, btnListIssuedBooks, btnReturnToday, btnOverdueBooks };
        for (SidebarButton btn : navButtons) {
            btn.setActive(btn == activeBtn);
        }
    }
    
    private JPanel createPageHeader(String titleText, String subtitleText) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(0, 0, 15, 0));
        
        JLabel title = new JLabel(titleText, SwingConstants.CENTER);
        title.setFont(FONT_TITLE);
        title.setForeground(TEXT_DARK);
        
        JLabel subtitle = new JLabel(subtitleText, SwingConstants.CENTER);
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitle.setForeground(Color.GRAY);
        
        panel.add(title, BorderLayout.CENTER);
        panel.add(subtitle, BorderLayout.SOUTH);
        return panel;
    }
    
    private JScrollPane styleTable(JTable table) {
        table.setFont(FONT_TABLE_CONTENT);
        table.setRowHeight(36);
        table.setSelectionBackground(HOVER_BLUE);
        table.setSelectionForeground(TEXT_DARK);
        table.setShowGrid(true);
        table.setGridColor(new Color(240, 240, 240));
        table.setIntercellSpacing(new Dimension(0, 0));
        
        JTableHeader header = table.getTableHeader();
        header.setPreferredSize(new Dimension(100, 42));
        
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                c.setBackground(PRIMARY_BLUE);
                c.setForeground(Color.WHITE);
                c.setFont(FONT_TABLE_HEADER);
                setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 0, 1, new Color(47, 128, 237).darker()),
                    new EmptyBorder(0, 10, 0, 10)
                ));
                return c;
            }
        });
        
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(249, 250, 251));
                }
                setBorder(new EmptyBorder(0, 10, 0, 10));
                return c;
            }
        };
        
        table.setDefaultRenderer(Object.class, renderer);
        table.setDefaultRenderer(String.class, renderer);
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_GRAY));
        scrollPane.getViewport().setBackground(Color.WHITE);
        return scrollPane;
    }
    
    private void initPanelReturnToday() {
        panelReturnToday = new JPanel(new BorderLayout());
        panelReturnToday.setBackground(Color.WHITE);
        panelReturnToday.add(createPageHeader("Books to be returned Today", "Manage today's pending returns"), BorderLayout.NORTH);
        
        returnTodayTable = new JTable(new DefaultTableModel(
            new Object[][]{},
            new String[]{"Issue ID", "Book Title", "USN", "Student Name", "Issue Date", "Return Date", "Book ISBN"}
        ) {
            public boolean isCellEditable(int rowIndex, int columnIndex) { return false; }
        });
        panelReturnToday.add(styleTable(returnTodayTable), BorderLayout.CENTER);
    }
    
    private void initPanelListBooks() {
        panelListBooks = new JPanel(new BorderLayout());
        panelListBooks.setBackground(Color.WHITE);
        panelListBooks.add(createPageHeader("List of Books", "View, update, and manage all books in the library"), BorderLayout.NORTH);
        
        bookAuthorTable = new JTable(new DefaultTableModel(
            new Object[][]{},
            new String[]{"Book ISBN", "Book Title", "Category", "Quantity", "Author Name"}
        ) {
            public boolean isCellEditable(int rowIndex, int columnIndex) { return false; }
        });
        panelListBooks.add(styleTable(bookAuthorTable), BorderLayout.CENTER);

        // Action panel for update, delete, refresh
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 12));
        actionPanel.setBackground(Color.WHITE);
        btnEditBook = createStyledButton("Update Selected Book");
        btnDeleteBook = createStyledButton("Delete Selected Book");
        btnDeleteBook.setBackground(new Color(220, 53, 69)); // red for delete
        btnRefreshBooks = createStyledButton("Refresh List");
        
        actionPanel.add(btnEditBook);
        actionPanel.add(btnDeleteBook);
        actionPanel.add(btnRefreshBooks);
        panelListBooks.add(actionPanel, BorderLayout.SOUTH);
    }
    
    private void initPanelSearchBook() {
        panelSearchBook = new JPanel(new BorderLayout());
        panelSearchBook.setBackground(Color.WHITE);
        panelSearchBook.add(createPageHeader("Search Book", "Find books by Title, Category, Author, or ISBN"), BorderLayout.NORTH);
        
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        topPanel.setBackground(Color.WHITE);
        
        txtSearch = createStyledTextField(300);
        comboBoxSearchBy = createStyledComboBox(new String[]{"Title", "Category", "Author", "ISBN"});
        btnSearch = createStyledButton("Search");
        
        topPanel.add(txtSearch);
        topPanel.add(comboBoxSearchBy);
        topPanel.add(btnSearch);
        
        searchTable = new JTable(new DefaultTableModel(
            new Object[][]{},
            new String[]{"Book ISBN", "Book Title", "Category", "Quantity", "Author"}
        ) {
            public boolean isCellEditable(int rowIndex, int columnIndex) { return false; }
        });
        
        JPanel centerContainer = new JPanel(new BorderLayout());
        centerContainer.setBackground(Color.WHITE);
        centerContainer.add(topPanel, BorderLayout.NORTH);
        centerContainer.add(styleTable(searchTable), BorderLayout.CENTER);
        panelSearchBook.add(centerContainer, BorderLayout.CENTER);
    }
    
    private void initPanelIssuedBooks() {
        panelIssuedBooks = new JPanel(new BorderLayout());
        panelIssuedBooks.setBackground(Color.WHITE);
        panelIssuedBooks.add(createPageHeader("Return Book", "Search and return issued books"), BorderLayout.NORTH);
        
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        topPanel.setBackground(Color.WHITE);
        
        topPanel.add(new JLabel("USN:"));
        txtUsn = createStyledTextField(150);
        btnSearchByUsn = createStyledButton("Search");
        btnReturn = createStyledButton("Return Selected Book");
        
        topPanel.add(txtUsn);
        topPanel.add(btnSearchByUsn);
        
        issuedBooksTable = new JTable(new DefaultTableModel(
            new Object[][]{},
            new String[]{"Issue ID", "Book Title", "USN", "Student Name", "Issue Date", "Return Date", "Book ISBN"}
        ) {
            public boolean isCellEditable(int rowIndex, int columnIndex) { return false; }
        });
        
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setBackground(Color.WHITE);
        bottomPanel.add(btnReturn);
        
        JPanel centerContainer = new JPanel(new BorderLayout());
        centerContainer.setBackground(Color.WHITE);
        centerContainer.add(topPanel, BorderLayout.NORTH);
        centerContainer.add(styleTable(issuedBooksTable), BorderLayout.CENTER);
        centerContainer.add(bottomPanel, BorderLayout.SOUTH);
        panelIssuedBooks.add(centerContainer, BorderLayout.CENTER);
    }
    
    private void initPanelAddBook() {
        panelAddBook = new JPanel(new BorderLayout());
        panelAddBook.setBackground(Color.WHITE);
        panelAddBook.add(createPageHeader("Add Book", "Enter book details to add to the library"), BorderLayout.NORTH);
        
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        txtISBN = createStyledTextField(240);
        txtTitle = createStyledTextField(240);
        txtCategory = createStyledTextField(120);
        comboBoxCategory = createStyledComboBox(dao.getAllCategory());
        txtAuthorName = createStyledTextField(240);
        txtAuthorEmail = createStyledTextField(240);
        txtQuantity = createStyledTextField(240);
        btnAdd = createStyledButton("Add Book");
        
        int row = 0;
        addFormField(formPanel, gbc, "Book ISBN", txtISBN, row++);
        addFormField(formPanel, gbc, "Book Title", txtTitle, row++);
        
        gbc.gridx = 0; gbc.gridy = row; formPanel.add(new JLabel("Category"), gbc);
        gbc.gridx = 1; 
        JPanel catPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        catPanel.setBackground(Color.WHITE);
        catPanel.add(txtCategory);
        catPanel.add(Box.createRigidArea(new Dimension(10, 0)));
        catPanel.add(comboBoxCategory);
        formPanel.add(catPanel, gbc);
        row++;
        
        addFormField(formPanel, gbc, "Author Name", txtAuthorName, row++);
        addFormField(formPanel, gbc, "Author Email", txtAuthorEmail, row++);
        addFormField(formPanel, gbc, "Quantity / Stock", txtQuantity, row++);
        
        gbc.gridx = 1; gbc.gridy = row; gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(25, 10, 10, 10);
        formPanel.add(btnAdd, gbc);
        
        JPanel centerWrapper = new JPanel(new GridBagLayout());
        centerWrapper.setBackground(Color.WHITE);
        centerWrapper.add(formPanel);
        panelAddBook.add(centerWrapper, BorderLayout.CENTER);
    }
    
    private void initPanelIssueBook() {
        panelIssueBook = new JPanel(new BorderLayout());
        panelIssueBook.setBackground(Color.WHITE);
        panelIssueBook.add(createPageHeader("Issue Book", "Search book and student to issue a book"), BorderLayout.NORTH);
        
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0; gbc.weighty = 0.5;
        
        // Book Search Section
        JPanel bookSection = new JPanel(new BorderLayout(0, 8));
        bookSection.setBackground(Color.WHITE);
        JPanel bookSearchTop = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        bookSearchTop.setBackground(Color.WHITE);
        bookSearchTop.add(new JLabel("Search Book:"));
        txtSearchBook = createStyledTextField(150);
        ComboBoxSearchBook = createStyledComboBox(new String[]{"Title", "Category", "Author", "ISBN"});
        btnSearchBookIssue = createStyledButton("Search");
        bookSearchTop.add(txtSearchBook);
        bookSearchTop.add(ComboBoxSearchBook);
        bookSearchTop.add(btnSearchBookIssue);
        bookSection.add(bookSearchTop, BorderLayout.NORTH);
        
        bookTable = new JTable(new DefaultTableModel(new Object[][]{}, new String[]{"Book ISBN", "Book Title", "Category", "Quantity", "Author"}) {
            public boolean isCellEditable(int rowIndex, int columnIndex) { return false; }
        });
        bookSection.add(styleTable(bookTable), BorderLayout.CENTER);
        
        // Student Search Section
        JPanel studentSection = new JPanel(new BorderLayout(0, 8));
        studentSection.setBackground(Color.WHITE);
        JPanel studentSearchTop = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        studentSearchTop.setBackground(Color.WHITE);
        studentSearchTop.add(new JLabel("Student USN:"));
        txtUsnSearch = createStyledTextField(130);
        btnSearchBookIssue1 = createStyledButton("Search");
        btnAddStudent = createStyledButton("Add Student");
        btnEditStudent = createStyledButton("Update Student");
        btnDeleteStudent = createStyledButton("Delete Student");
        btnDeleteStudent.setBackground(new Color(220, 53, 69)); // red for delete
        btnListAllStudents = createStyledButton("All Students");

        studentSearchTop.add(txtUsnSearch);
        studentSearchTop.add(btnSearchBookIssue1);
        studentSearchTop.add(btnAddStudent);
        studentSearchTop.add(btnEditStudent);
        studentSearchTop.add(btnDeleteStudent);
        studentSearchTop.add(btnListAllStudents);
        studentSection.add(studentSearchTop, BorderLayout.NORTH);
        
        studentTable = new JTable(new DefaultTableModel(new Object[][]{}, new String[]{"USN", "Name"}) {
            public boolean isCellEditable(int rowIndex, int columnIndex) { return false; }
        });
        studentSection.add(styleTable(studentTable), BorderLayout.CENTER);
        
        gbc.gridx = 0; gbc.gridy = 0; centerPanel.add(bookSection, gbc);
        gbc.gridy = 1; centerPanel.add(studentSection, gbc);
        
        btnIssue = createStyledButton("Issue Book");
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setBackground(Color.WHITE);
        bottomPanel.add(btnIssue);
        
        panelIssueBook.add(centerPanel, BorderLayout.CENTER);
        panelIssueBook.add(bottomPanel, BorderLayout.SOUTH);
    }

    private void initPanelOverdueBooks() {
        panelOverdueBooks = new JPanel(new BorderLayout());
        panelOverdueBooks.setBackground(Color.WHITE);
        panelOverdueBooks.add(createPageHeader("Overdue Books & Fines Report", "Track overdue book loans and calculate accumulated late fees"), BorderLayout.NORTH);

        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        topBar.setBackground(Color.WHITE);
        lblOverdueSummary = new JLabel("Summary: Please click Refresh to load overdue records.");
        lblOverdueSummary.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblOverdueSummary.setForeground(new Color(220, 53, 69));
        btnRefreshOverdue = createStyledButton("Refresh Report");
        topBar.add(lblOverdueSummary);
        topBar.add(btnRefreshOverdue);

        overdueTable = new JTable(new DefaultTableModel(
            new Object[][]{},
            new String[]{"Issue ID", "Book Title", "Student USN", "Student Name", "Issue Date", "Due Date", "Days Overdue", "Fine Due (\u00A3)", "ISBN"}
        ) {
            public boolean isCellEditable(int rowIndex, int columnIndex) { return false; }
        });

        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        bottomBar.setBackground(Color.WHITE);
        btnReturnOverdue = createStyledButton("Return Selected Book & Settle Fine");
        bottomBar.add(btnReturnOverdue);

        JPanel centerContainer = new JPanel(new BorderLayout());
        centerContainer.setBackground(Color.WHITE);
        centerContainer.add(topBar, BorderLayout.NORTH);
        centerContainer.add(styleTable(overdueTable), BorderLayout.CENTER);
        centerContainer.add(bottomBar, BorderLayout.SOUTH);

        panelOverdueBooks.add(centerContainer, BorderLayout.CENTER);
    }

    private void refreshOverdueBooks() {
        try {
            Date curDate = Calendar.getInstance().getTime();
            DefaultTableModel model = dao.getOverdueBooks(curDate, Book.DAILY_FINE_RATE);
            overdueTable.setModel(model);
            int count = model.getRowCount();
            double totalFine = 0.0;
            for (int i = 0; i < count; i++) {
                try {
                    String fineStr = (String) model.getValueAt(i, 7);
                    totalFine += Double.parseDouble(fineStr);
                } catch (Exception ignored) {
                }
            }
            lblOverdueSummary.setText(String.format("Overdue Loans: %d   |   Total Fines: \u00A3%.2f   (Standard Rate: \u00A3%.2f/day)", count, totalFine, Book.DAILY_FINE_RATE));
            if (count == 0) {
                lblOverdueSummary.setForeground(new Color(40, 167, 69));
                JOptionPane.showMessageDialog(panelOverdueBooks, "Great! There are no overdue books at this time.", "No Overdue Books", JOptionPane.INFORMATION_MESSAGE);
            } else {
                lblOverdueSummary.setForeground(new Color(220, 53, 69));
            }
        } catch (Throwable ex) {
            JOptionPane.showMessageDialog(panelOverdueBooks, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void addFormField(JPanel panel, GridBagConstraints gbc, String label, JTextField field, int row) {
        gbc.gridx = 0; gbc.gridy = row;
        JLabel l = new JLabel(label);
        l.setFont(FONT_BUTTON);
        panel.add(l, gbc);
        gbc.gridx = 1;
        panel.add(field, gbc);
    }
    
    private JTextField createStyledTextField(int width) {
        JTextField tf = new JTextField();
        tf.setPreferredSize(new Dimension(width, 35));
        tf.setFont(FONT_TABLE_CONTENT);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_GRAY), 
            new EmptyBorder(5, 10, 5, 10)));
        return tf;
    }
    
    private JComboBox<String> createStyledComboBox(String[] items) {
        JComboBox<String> cb = new JComboBox<>(items);
        cb.setPreferredSize(new Dimension(130, 35));
        cb.setFont(FONT_TABLE_CONTENT);
        cb.setBackground(Color.WHITE);
        return cb;
    }
    
    private JButton createStyledButton(String text) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                super.paintComponent(g);
                g2.dispose();
            }
        };
        btn.setFont(FONT_BUTTON);
        btn.setForeground(Color.WHITE);
        btn.setBackground(PRIMARY_BLUE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setMargin(new Insets(8, 18, 8, 18));
        return btn;
    }

    private void addEventListeners() {
        // Navigation events
        btnAddBook.addActionListener(e -> switchPanel("Add Book", btnAddBook));
        btnSearchBook.addActionListener(e -> switchPanel("Search Book", btnSearchBook));
        btnListBooks.addActionListener(e -> {
            switchPanel("List Books", btnListBooks);
            try {
                bookAuthorTable.setModel(dao.getTableBookAuthor());
                if (bookAuthorTable.getModel().getRowCount() == 0) {
                    JOptionPane.showMessageDialog(panelListBooks, "No books found in the database.", "Nothing Found", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (Throwable ex) {
                JOptionPane.showMessageDialog(null, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        btnIssueBook.addActionListener(e -> switchPanel("Issue Book", btnIssueBook));
        btnListIssuedBooks.addActionListener(e -> {
            switchPanel("Issued Books", btnListIssuedBooks);
            try {
                issuedBooksTable.setModel(dao.listIssuedBooks());
                if (issuedBooksTable.getModel().getRowCount() == 0) {
                    JOptionPane.showMessageDialog(panelIssueBook, "No issued books found.", "No Record", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (Throwable ex) {
                JOptionPane.showMessageDialog(panelIssueBook, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        btnReturnToday.addActionListener(e -> {
            switchPanel("Return Today", btnReturnToday);
            Calendar cal = Calendar.getInstance();
            Date curDate = cal.getTime();
            try {
                returnTodayTable.setModel(dao.getBookToReturn(curDate));
                if (returnTodayTable.getModel().getRowCount() == 0) {
                    JOptionPane.showMessageDialog(panelReturnToday, "No books scheduled to return today.", "Message", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (Throwable ex) {
                JOptionPane.showMessageDialog(panelReturnToday, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        btnOverdueBooks.addActionListener(e -> {
            switchPanel("Overdue Books", btnOverdueBooks);
            refreshOverdueBooks();
        });
        btnRefreshOverdue.addActionListener(e -> refreshOverdueBooks());

        btnLogout.addActionListener(e -> {
            this.dispose();
            LoginFrame.loggedIn = false;
            new LoginFrame().setVisible(true);
        });

        // Add Book functionality with ValidationUtil
        comboBoxCategory.addActionListener(e -> {
            String val = (String) comboBoxCategory.getSelectedItem();
            if (val != null && !val.equals("Select")) txtCategory.setText(val);
        });
        btnAdd.addActionListener(e -> {
            String isbn = txtISBN.getText().trim();
            String title = txtTitle.getText().trim();
            String category = txtCategory.getText().trim();
            String q = txtQuantity.getText().trim();
            String name = txtAuthorName.getText().trim();
            String email = txtAuthorEmail.getText().trim();

            try {
                ValidationUtil.validateIsbn(isbn);
                ValidationUtil.validateNotEmpty(title, "Book Title");
                ValidationUtil.validateNotEmpty(category, "Category");
                int numBooks = ValidationUtil.parseAndValidateStock(q);
                ValidationUtil.validateNotEmpty(name, "Author Name");
                if (!email.isEmpty()) {
                    ValidationUtil.validateEmail(email);
                }

                Book book = new Book(isbn, title, category, numBooks);
                Author author = new Author(name, email, isbn);

                if (dao.addBook(book) && dao.addAuthor(author)) {
                    JOptionPane.showMessageDialog(panelAddBook, "Book details added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    txtISBN.setText("");
                    txtTitle.setText("");
                    txtCategory.setText("");
                    txtQuantity.setText("");
                    txtAuthorName.setText("");
                    txtAuthorEmail.setText("");
                } else {
                    JOptionPane.showMessageDialog(panelAddBook, "Failed to add book. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (ValidationException ve) {
                JOptionPane.showMessageDialog(panelAddBook, ve.getMessage(), "Validation Error", JOptionPane.WARNING_MESSAGE);
            } catch (LibraryException le) {
                JOptionPane.showMessageDialog(panelAddBook, "Database Error: " + le.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Throwable ex) {
                JOptionPane.showMessageDialog(panelAddBook, "Unexpected Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Book Management (Update & Delete) in List Books
        btnEditBook.addActionListener(e -> {
            int row = bookAuthorTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(panelListBooks, "Please select a book from the table to update.", "Selection Required", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String isbn = (String) bookAuthorTable.getModel().getValueAt(row, 0);
            String title = (String) bookAuthorTable.getModel().getValueAt(row, 1);
            String category = (String) bookAuthorTable.getModel().getValueAt(row, 2);
            String quantity = (String) bookAuthorTable.getModel().getValueAt(row, 3);
            String author = (String) bookAuthorTable.getModel().getValueAt(row, 4);

            DialogEditBook editDialog = new DialogEditBook(this, isbn, title, category, quantity, author);
            editDialog.setVisible(true);
            if (editDialog.isUpdated()) {
                bookAuthorTable.setModel(dao.getTableBookAuthor());
            }
        });

        btnDeleteBook.addActionListener(e -> {
            int row = bookAuthorTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(panelListBooks, "Please select a book from the table to delete.", "Selection Required", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String isbn = (String) bookAuthorTable.getModel().getValueAt(row, 0);
            String title = (String) bookAuthorTable.getModel().getValueAt(row, 1);

            int confirm = JOptionPane.showConfirmDialog(panelListBooks,
                    "Are you sure you want to permanently delete:\n\"" + title + "\" (ISBN: " + isbn + ")?",
                    "Confirm Book Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    boolean success = dao.deleteBook(isbn);
                    if (success) {
                        JOptionPane.showMessageDialog(panelListBooks, "Book deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                        bookAuthorTable.setModel(dao.getTableBookAuthor());
                    } else {
                        JOptionPane.showMessageDialog(panelListBooks, "Book record not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (LibraryException le) {
                    JOptionPane.showMessageDialog(panelListBooks, le.getMessage(), "Cannot Delete Book", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnRefreshBooks.addActionListener(e -> {
            try {
                bookAuthorTable.setModel(dao.getTableBookAuthor());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panelListBooks, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Search Book functionality
        comboBoxSearchBy.addActionListener(e -> searchBy = (String) comboBoxSearchBy.getSelectedItem());
        btnSearch.addActionListener(e -> {
            if (searchBy == null) searchBy = "Title";
            String txt = txtSearch.getText().trim();
            if (txt.length() == 0) {
                JOptionPane.showMessageDialog(panelSearchBook, "Please enter a search term.", "Input Required", JOptionPane.WARNING_MESSAGE);
                return;
            }
            try {
                switch (searchBy) {
                    case "Title": searchTable.setModel(dao.getByTitle(txt)); break;
                    case "Category": searchTable.setModel(dao.getByCategory(txt)); break;
                    case "Author": searchTable.setModel(dao.getByAuthor(txt)); break;
                    case "ISBN": searchTable.setModel(dao.getByIsbn(txt)); break;
                }
                if (searchTable.getModel().getRowCount() == 0) {
                    JOptionPane.showMessageDialog(panelSearchBook, "No records found matching '" + txt + "'.", "Nothing Found", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (Throwable ex) {
                JOptionPane.showMessageDialog(panelSearchBook, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Issue Book functionality
        ComboBoxSearchBook.addActionListener(e -> searchBookBy = (String) ComboBoxSearchBook.getSelectedItem());
        btnSearchBookIssue.addActionListener(e -> {
            if (searchBookBy == null) searchBookBy = "Title";
            String txt = txtSearchBook.getText().trim();
            if (txt.length() == 0) {
                JOptionPane.showMessageDialog(panelIssueBook, "Please enter a book search term.", "Input Required", JOptionPane.WARNING_MESSAGE);
                return;
            }
            try {
                switch (searchBookBy) {
                    case "Title": bookTable.setModel(dao.getByTitle(txt)); break;
                    case "Category": bookTable.setModel(dao.getByCategory(txt)); break;
                    case "Author": bookTable.setModel(dao.getByAuthor(txt)); break;
                    case "ISBN": bookTable.setModel(dao.getByIsbn(txt)); break;
                }
                if (bookTable.getModel().getRowCount() == 0) {
                    JOptionPane.showMessageDialog(panelIssueBook, "No books found matching '" + txt + "'.", "Nothing Found", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (Throwable ex) {
                JOptionPane.showMessageDialog(panelIssueBook, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnSearchBookIssue1.addActionListener(e -> {
            String usn = txtUsnSearch.getText().trim();
            try {
                if (usn.length() != 0) {
                    studentTable.setModel(dao.getStudentbyUsn(usn));
                } else {
                    JOptionPane.showMessageDialog(panelIssueBook, "Please enter a student USN.", "Input Required", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                if (studentTable.getModel().getRowCount() == 0) {
                    JOptionPane.showMessageDialog(panelIssueBook, "No student found with USN '" + usn + "'.", "Nothing Found", JOptionPane.INFORMATION_MESSAGE);
                    DialogAddStudent dialog = new DialogAddStudent(this, true);
                    dialog.setLocationRelativeTo(btnAddStudent);
                    dialog.setVisible(true);
                    txtUsnSearch.setText(dialog.usn);
                    if (dialog.usn != null && !dialog.usn.isEmpty()) {
                        studentTable.setModel(dao.getStudentbyUsn(dialog.usn));
                    }
                }
            } catch (Throwable ex) {
                JOptionPane.showMessageDialog(panelIssueBook, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnAddStudent.addActionListener(e -> {
            DialogAddStudent dialog = new DialogAddStudent(this, true);
            dialog.setLocationRelativeTo(btnAddStudent);
            dialog.setVisible(true);
            txtUsnSearch.setText(dialog.usn);
            if (dialog.usn != null && !dialog.usn.isEmpty()) {
                studentTable.setModel(dao.getStudentbyUsn(dialog.usn));
            }
        });

        btnEditStudent.addActionListener(e -> {
            int row = studentTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(panelIssueBook, "Please select a student from the table to update.", "Selection Required", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String usn = (String) studentTable.getModel().getValueAt(row, 0);
            String name = (String) studentTable.getModel().getValueAt(row, 1);

            DialogEditStudent editDialog = new DialogEditStudent(this, usn, name);
            editDialog.setVisible(true);
            if (editDialog.isUpdated()) {
                studentTable.setModel(dao.getStudentbyUsn(usn));
            }
        });

        btnDeleteStudent.addActionListener(e -> {
            int row = studentTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(panelIssueBook, "Please select a student from the table to delete.", "Selection Required", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String usn = (String) studentTable.getModel().getValueAt(row, 0);
            String name = (String) studentTable.getModel().getValueAt(row, 1);

            int confirm = JOptionPane.showConfirmDialog(panelIssueBook,
                    "Are you sure you want to permanently delete student:\n\"" + name + "\" (USN: " + usn + ")?",
                    "Confirm Student Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    boolean success = dao.deleteStudent(usn);
                    if (success) {
                        JOptionPane.showMessageDialog(panelIssueBook, "Student deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                        studentTable.setModel(dao.getAllStudents());
                    } else {
                        JOptionPane.showMessageDialog(panelIssueBook, "Student not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (LibraryException le) {
                    JOptionPane.showMessageDialog(panelIssueBook, le.getMessage(), "Cannot Delete Student", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnListAllStudents.addActionListener(e -> {
            try {
                studentTable.setModel(dao.getAllStudents());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panelIssueBook, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnIssue.addActionListener(e -> {
            int idxBook = bookTable.getSelectedRow();
            int idxStudent = studentTable.getSelectedRow();
            if (idxBook == -1 || idxStudent == -1) {
                JOptionPane.showMessageDialog(panelIssueBook, "Please select both a book and a student from the tables.", "Selection Required", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String usn = (String) studentTable.getModel().getValueAt(idxStudent, 0);
            String name = (String) studentTable.getModel().getValueAt(idxStudent, 1);
            String isbn = (String) bookTable.getModel().getValueAt(idxBook, 0);
            int count = Integer.parseInt((String) bookTable.getModel().getValueAt(idxBook, 3));
            if (count <= 0) {
                JOptionPane.showMessageDialog(panelIssueBook, "This book is currently out of stock.", "Book Unavailable", JOptionPane.WARNING_MESSAGE);
                return;
            }
            try {
                Calendar cal = Calendar.getInstance();
                Date curDate = cal.getTime();
                Date issue_date = curDate;
                cal.add(Calendar.DATE, Book.STANDARD_LOAN_DAYS);
                Date return_date = cal.getTime();

                if (dao.issueBook(new Issue(usn, issue_date, return_date, isbn))) {
                    JOptionPane.showMessageDialog(panelIssueBook,
                        "Book Issued Successfully!\nReturn Due Date: " + new SimpleDateFormat("yyyy-MM-dd").format(return_date),
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                    // Refresh book table
                    bookTable.setModel(dao.getByIsbn(isbn));
                } else {
                    JOptionPane.showMessageDialog(panelIssueBook, "Failed to issue book.", "Operation Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Throwable ex) {
                JOptionPane.showMessageDialog(panelIssueBook, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Return Book functionality
        btnSearchByUsn.addActionListener(e -> {
            String usn = txtUsn.getText().trim();
            if (usn.length() == 0) {
                JOptionPane.showMessageDialog(panelIssuedBooks, "Please enter student USN.", "Input Required", JOptionPane.WARNING_MESSAGE);
                return;
            }
            try {
                issuedBooksTable.setModel(dao.listBookByUsn(usn));
                if (issuedBooksTable.getModel().getRowCount() == 0) {
                    JOptionPane.showMessageDialog(panelIssuedBooks, "No issued books found for USN: " + usn, "No Records", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (Throwable ex) {
                JOptionPane.showMessageDialog(panelIssuedBooks, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnReturn.addActionListener(e -> {
            int row = issuedBooksTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(panelIssuedBooks, "Please select an issued record to return.", "Selection Required", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int id = Integer.parseInt((String) issuedBooksTable.getModel().getValueAt(row, 0));
            String title = (String) issuedBooksTable.getModel().getValueAt(row, 1);
            String isbn = (String) issuedBooksTable.getModel().getValueAt(row, 6);
            try {
                if (dao.returnBook(id, isbn)) {
                    JOptionPane.showMessageDialog(panelIssuedBooks, "Book \"" + title + "\" returned successfully!", "Return Confirmed", JOptionPane.INFORMATION_MESSAGE);
                    issuedBooksTable.setModel(dao.listIssuedBooks());
                } else {
                    JOptionPane.showMessageDialog(panelIssuedBooks, "Failed to return book.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panelIssuedBooks, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Return Overdue Book & Settle Fine
        btnReturnOverdue.addActionListener(e -> {
            int row = overdueTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(panelOverdueBooks, "Please select an overdue book from the table.", "Selection Required", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int issueId = Integer.parseInt((String) overdueTable.getModel().getValueAt(row, 0));
            String title = (String) overdueTable.getModel().getValueAt(row, 1);
            String studentName = (String) overdueTable.getModel().getValueAt(row, 3);
            String daysOverdue = (String) overdueTable.getModel().getValueAt(row, 6);
            String fineDue = (String) overdueTable.getModel().getValueAt(row, 7);
            String isbn = (String) overdueTable.getModel().getValueAt(row, 8);

            int confirm = JOptionPane.showConfirmDialog(panelOverdueBooks,
                "Return Overdue Book:\n"
                + "Title: " + title + "\n"
                + "Student: " + studentName + "\n"
                + "Days Overdue: " + daysOverdue + " days\n"
                + "Fine to Collect: \u00A3" + fineDue + "\n\n"
                + "Confirm return and fine collection?",
                "Confirm Return & Fine Settle",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    if (dao.returnBook(issueId, isbn)) {
                        JOptionPane.showMessageDialog(panelOverdueBooks,
                            "Book returned successfully!\nFine of \u00A3" + fineDue + " has been settled.",
                            "Return & Fine Settled", JOptionPane.INFORMATION_MESSAGE);
                        refreshOverdueBooks();
                    } else {
                        JOptionPane.showMessageDialog(panelOverdueBooks, "Failed to return overdue book.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(panelOverdueBooks, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    public static void main(String args[]) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        EventQueue.invokeLater(() -> {
            if (!LoginFrame.loggedIn) {
                new LoginFrame().setVisible(true);
                return;
            }
            new MainFrame().setVisible(true);
        });
    }
}

class CustomIcon implements Icon {
    private String type;
    private Color color;
    public CustomIcon(String type, Color color) { this.type = type; this.color = color; }
    public void setColor(Color c) { this.color = c; }
    @Override public int getIconWidth() { return 24; }
    @Override public int getIconHeight() { return 24; }
    @Override public void paintIcon(Component c, Graphics g, int x, int y) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(color);
        g2.setStroke(new BasicStroke(2f));
        g2.translate(x, y);
        if(type.equals("add")) {
            g2.drawRoundRect(2, 2, 20, 20, 4, 4);
            g2.drawLine(12, 7, 12, 17);
            g2.drawLine(7, 12, 17, 12);
        } else if(type.equals("search")) {
            g2.drawOval(4, 4, 12, 12);
            g2.drawLine(13, 13, 20, 20);
        } else if(type.equals("list")) {
            g2.drawLine(4, 6, 20, 6);
            g2.drawLine(4, 12, 20, 12);
            g2.drawLine(4, 18, 20, 18);
        } else if(type.equals("issue")) {
            g2.drawRoundRect(2, 6, 20, 16, 4, 4);
            g2.drawLine(12, 16, 12, 2);
            g2.drawLine(12, 2, 7, 7);
            g2.drawLine(12, 2, 17, 7);
        } else if(type.equals("issued")) {
            g2.drawRoundRect(4, 4, 16, 18, 2, 2);
            g2.drawLine(8, 4, 8, 2);
            g2.drawLine(16, 4, 16, 2);
            g2.drawLine(8, 2, 16, 2);
        } else if(type.equals("return")) {
            g2.drawRoundRect(2, 4, 20, 18, 2, 2);
            g2.drawLine(2, 10, 22, 10);
            g2.drawLine(6, 2, 6, 6);
            g2.drawLine(18, 2, 18, 6);
        } else if(type.equals("overdue")) {
            g2.drawOval(2, 2, 20, 20);
            g2.drawLine(12, 6, 12, 13);
            g2.drawLine(12, 16, 12, 18);
        } else if(type.equals("logout")) {
            g2.drawRoundRect(8, 2, 14, 20, 2, 2);
            g2.drawLine(12, 12, 2, 12);
            g2.drawLine(2, 12, 6, 8);
            g2.drawLine(2, 12, 6, 16);
        } else if(type.equals("book")) {
            g2.drawRoundRect(2, 2, 20, 20, 2, 2);
            g2.drawLine(12, 2, 12, 22);
        } else if(type.equals("user")) {
            g2.drawOval(7, 2, 10, 10);
            g2.drawArc(2, 14, 20, 16, 0, 180);
        }
        g2.dispose();
    }
}

class SidebarButton extends JButton {
    private boolean isActive = false;
    private Color primaryBlue = new Color(47, 128, 237);
    private Color hoverColor = new Color(234, 244, 255);
    private CustomIcon customIcon;

    public SidebarButton(String text, String iconType) {
        super(text);
        this.customIcon = new CustomIcon(iconType, primaryBlue);
        setIcon(customIcon);
        setFont(new Font("Segoe UI", Font.BOLD, 15));
        setForeground(primaryBlue);
        setBackground(Color.WHITE);
        setFocusPainted(false);
        setBorderPainted(false);
        setContentAreaFilled(false);
        setOpaque(false);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setHorizontalAlignment(SwingConstants.LEFT);
        setIconTextGap(15);
        setMargin(new Insets(10, 20, 10, 20));

        addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { if (!isActive) { setBackground(hoverColor); repaint(); } }
            public void mouseExited(MouseEvent e) { if (!isActive) { setBackground(Color.WHITE); repaint(); } }
        });
    }

    public void setActive(boolean active) {
        this.isActive = active;
        if (active) {
            setBackground(primaryBlue);
            setForeground(Color.WHITE);
            customIcon.setColor(Color.WHITE);
        } else {
            setBackground(Color.WHITE);
            setForeground(primaryBlue);
            customIcon.setColor(primaryBlue);
        }
        repaint();
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
        super.paintComponent(g);
        g2.dispose();
    }
}

class LogoutButton extends JButton {
    public LogoutButton() {
        super("Logout");
        setIcon(new CustomIcon("logout", Color.RED));
        setFont(new Font("Segoe UI", Font.BOLD, 16));
        setForeground(Color.RED);
        setFocusPainted(false);
        setBorderPainted(false);
        setContentAreaFilled(false);
        setOpaque(false);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setHorizontalAlignment(SwingConstants.LEFT);
        setIconTextGap(15);
        setMargin(new Insets(10, 20, 10, 20));

        addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { setBackground(new Color(255, 235, 235)); repaint(); }
            public void mouseExited(MouseEvent e) { setBackground(Color.WHITE); repaint(); }
        });
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(getBackground() == null ? Color.WHITE : getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
        super.paintComponent(g);
        g2.dispose();
    }
}
