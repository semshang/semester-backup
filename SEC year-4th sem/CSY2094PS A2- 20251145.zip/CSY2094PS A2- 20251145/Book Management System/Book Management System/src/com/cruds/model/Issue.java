package com.cruds.model;

import java.util.Date;

/**
 * Represents a book issue transaction in the Library Management System.
 */
public class Issue {
	
	private int id;
	private String usn;
	private Date issue_date;
	private Date return_date;
	private String book_isbn;
	
	/**
	 * Constructs a new Issue.
	 * @param usn the student's USN
	 * @param issue_date the date the book was issued
	 * @param return_date the expected date of return
	 * @param book_isbn the ISBN of the issued book
	 */
	public Issue(String usn, Date issue_date, Date return_date, String book_isbn) {
		this.usn = usn;
		this.issue_date = issue_date;
		this.return_date = return_date;
		this.book_isbn = book_isbn;
	}

	/**
	 * Gets the issue ID.
	 * @return the issue ID
	 */
	public int getId() {
		return id;
	}

	/**
	 * Gets the student's USN.
	 * @return the USN
	 */
	public String getUsn() {
		return usn;
	}

	/**
	 * Sets the student's USN.
	 * @param usn the USN to set
	 */
	public void setUsn(String usn) {
		this.usn = usn;
	}

	/**
	 * Gets the issue date.
	 * @return the issue date
	 */
	public Date getIssueDate() {
		return issue_date;
	}

	/**
	 * Sets the issue date.
	 * @param issue_date the issue date to set
	 */
	public void setIssueDate(Date issue_date) {
		this.issue_date = issue_date;
	}

	/**
	 * Gets the return date.
	 * @return the return date
	 */
	public Date getReturnDate() {
		return return_date;
	}
	
	/**
	 * Sets the return date.
	 * @param return_date the return date to set
	 */
	public void setReturnDate(Date return_date) {
		this.return_date = return_date;
	}

	/**
	 * Gets the associated book ISBN.
	 * @return the ISBN
	 */
	public String getBook_isbn() {
		return book_isbn;
	}

	/**
	 * Sets the associated book ISBN.
	 * @param book_isbn the ISBN to set
	 */
	public void setBook_isbn(String book_isbn) {
		this.book_isbn = book_isbn;
	}

	@Override
	public String toString() {
		return "" + id + "\t" + usn + "\t" + issue_date + "\t" + return_date + "\t" + book_isbn;
	}
}
