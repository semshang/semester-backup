package com.cruds.gui;

import com.cruds.db.BookDAO;
import com.cruds.exception.LibraryException;
import com.cruds.exception.ValidationException;
import com.cruds.model.Author;
import com.cruds.model.Book;
import com.cruds.util.ValidationUtil;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/**
 * Modal dialog for updating an existing Book and its Author information.
 * Uses ValidationUtil to ensure input integrity before persisting via BookDAO.
 */
public class DialogEditBook extends JDialog {

    private final String isbn;
    private final BookDAO dao;
    private boolean updated = false;

    private JTextField txtIsbn;
    private JTextField txtTitle;
    private JTextField txtCategory;
    private JTextField txtQuantity;
    private JTextField txtAuthorName;
    private JTextField txtAuthorEmail;

    private final Color PRIMARY_BLUE = new Color(47, 128, 237);
    private final Color TEXT_DARK = new Color(45, 45, 45);
    private final Color BORDER_GRAY = new Color(229, 229, 229);

    public DialogEditBook(Frame parent, String isbn, String initialTitle, String initialCategory,
                          String initialQuantity, String initialAuthor) {
        super(parent, "Update Book Details", true);
        this.isbn = isbn;
        this.dao = new BookDAO();

        initComponents(initialTitle, initialCategory, initialQuantity, initialAuthor);
        pack();
        setLocationRelativeTo(parent);
    }

    private void initComponents(String initialTitle, String initialCategory, String initialQuantity, String initialAuthor) {
        JPanel contentPane = new JPanel(new BorderLayout(15, 15));
        contentPane.setBackground(Color.WHITE);
        contentPane.setBorder(new EmptyBorder(20, 25, 20, 25));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        JLabel titleLabel = new JLabel("Update Book", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(TEXT_DARK);
        JLabel subtitleLabel = new JLabel("Edit details for ISBN: " + isbn, SwingConstants.CENTER);
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitleLabel.setForeground(Color.GRAY);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        headerPanel.add(subtitleLabel, BorderLayout.SOUTH);
        contentPane.add(headerPanel, BorderLayout.NORTH);

        // Form Fields
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtIsbn = createTextField(isbn);
        txtIsbn.setEditable(false);
        txtIsbn.setBackground(new Color(245, 245, 245));

        txtTitle = createTextField(initialTitle != null ? initialTitle : "");
        txtCategory = createTextField(initialCategory != null ? initialCategory : "");
        txtQuantity = createTextField(initialQuantity != null ? initialQuantity : "1");
        txtAuthorName = createTextField(initialAuthor != null && !initialAuthor.equals("-") ? initialAuthor : "");

        Author existingAuthor = dao.getAuthor(isbn);
        String initialEmail = (existingAuthor != null && existingAuthor.getEmail() != null) ? existingAuthor.getEmail() : "";
        txtAuthorEmail = createTextField(initialEmail);

        int row = 0;
        addFormRow(formPanel, gbc, "ISBN (Read-Only):", txtIsbn, row++);
        addFormRow(formPanel, gbc, "Book Title:", txtTitle, row++);
        addFormRow(formPanel, gbc, "Category:", txtCategory, row++);
        addFormRow(formPanel, gbc, "Quantity / Stock:", txtQuantity, row++);
        addFormRow(formPanel, gbc, "Author Name:", txtAuthorName, row++);
        addFormRow(formPanel, gbc, "Author Email:", txtAuthorEmail, row++);

        contentPane.add(formPanel, BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonPanel.setBackground(Color.WHITE);

        JButton btnCancel = new JButton("Cancel");
        btnCancel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnCancel.setFocusPainted(false);
        btnCancel.addActionListener(e -> dispose());

        JButton btnSave = new JButton("Save Changes");
        btnSave.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSave.setBackground(PRIMARY_BLUE);
        btnSave.setForeground(Color.WHITE);
        btnSave.setFocusPainted(false);
        btnSave.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSave.addActionListener(e -> onSave());

        buttonPanel.add(btnCancel);
        buttonPanel.add(btnSave);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);

        setContentPane(contentPane);
        setResizable(false);
    }

    private void addFormRow(JPanel panel, GridBagConstraints gbc, String label, JTextField field, int row) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0.3;
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lbl.setForeground(TEXT_DARK);
        panel.add(lbl, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.7;
        panel.add(field, gbc);
    }

    private JTextField createTextField(String text) {
        JTextField tf = new JTextField(text);
        tf.setPreferredSize(new Dimension(240, 32));
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_GRAY),
                new EmptyBorder(4, 8, 4, 8)));
        return tf;
    }

    private void onSave() {
        String title = txtTitle.getText().trim();
        String category = txtCategory.getText().trim();
        String qtyStr = txtQuantity.getText().trim();
        String authorName = txtAuthorName.getText().trim();
        String authorEmail = txtAuthorEmail.getText().trim();

        try {
            ValidationUtil.validateNotEmpty(title, "Book Title");
            ValidationUtil.validateNotEmpty(category, "Category");
            int quantity = ValidationUtil.parseAndValidateStock(qtyStr);
            ValidationUtil.validateNotEmpty(authorName, "Author Name");
            if (!authorEmail.isEmpty()) {
                ValidationUtil.validateEmail(authorEmail);
            }

            Book book = new Book(isbn, title, category, quantity);
            Author author = new Author(authorName, authorEmail, isbn);

            boolean success = dao.updateBook(book, author);
            if (success) {
                JOptionPane.showMessageDialog(this, "Book updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                updated = true;
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update book.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (ValidationException ve) {
            JOptionPane.showMessageDialog(this, ve.getMessage(), "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (LibraryException le) {
            JOptionPane.showMessageDialog(this, "Database error: " + le.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Checks whether the book was updated.
     *
     * @return true if updated
     */
    public boolean isUpdated() {
        return updated;
    }
}
